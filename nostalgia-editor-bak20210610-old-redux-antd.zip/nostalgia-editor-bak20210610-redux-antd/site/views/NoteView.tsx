import React from 'react';

import NoteContainer from '../components/notes/NoteContainer';

export default function NotesView() {
  return <NoteContainer />;
}
