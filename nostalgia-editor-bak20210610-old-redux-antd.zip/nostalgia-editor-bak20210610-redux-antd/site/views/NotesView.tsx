import React from 'react';

import NotesContainer from '../components/notes/NotesContainer';

export default function NotesView() {
  return <NotesContainer />;
  // return <h1>ddd</h1>;
}
