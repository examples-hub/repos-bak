import { applyMiddleware, combineReducers, createStore } from 'redux';
import { composeWithDevTools } from 'redux-devtools-extension';
import thunk from 'redux-thunk';

import interfaceReducer from './interface/reducers';
import noteReducer from './note/reducers';

const rootReducer = combineReducers({
  note: noteReducer,
  interface: interfaceReducer,
});

export type AppState = ReturnType<typeof rootReducer>;

const store = createStore(
  rootReducer,
  composeWithDevTools(applyMiddleware(thunk)),
);

export default store;
