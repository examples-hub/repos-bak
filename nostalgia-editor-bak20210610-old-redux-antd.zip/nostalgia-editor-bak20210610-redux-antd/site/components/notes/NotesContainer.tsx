import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

import { AppState } from '../../store';
import { toggleInterfaceItem } from '../../store/interface/operations';
import {
  addSelectedNote,
  removeSelectedNote,
  setActiveNote,
} from '../../store/note/actions';
import {
  browseNotes,
  createNote,
  deleteNote,
} from '../../store/note/operations';
import Notes from './Notes';
import DeleteNotesModal from './DeleteNotesModal';

/**
 * 主页默认显示的笔记列表，主要处理全局快捷键事件
 */
export default function NotesContainer() {
  const state = useSelector((state: AppState) => state);
  const { notes, fetchNotesStatus, activeNote, selectedNotes } = state.note;
  const [deleteNotesIsOpen, setDeleteNotesIsOpen] = useState<boolean>(false);
  const { getAccessTokenSilently, isAuthenticated, loginWithRedirect } = {
    getAccessTokenSilently: true,
    isAuthenticated: true,
    loginWithRedirect: () => {},
  };
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { spotlight } = state.interface;

  useEffect(() => {
    const handleKeyDown = async (e: KeyboardEvent) => {
      if (spotlight.isOpen) return;

      // ? await getAccessTokenSilently()
      const token = isAuthenticated ? undefined : undefined;

      switch (e.keyCode) {
        case 74: // 'j'
        case 40: // 'down'
          dispatch(toggleInterfaceItem('shortcuts', false));
          return dispatch(browseNotes({}, 'down'));
        case 75: // 'k'
        case 38: // 'up'
          dispatch(toggleInterfaceItem('shortcuts', false));
          return dispatch(browseNotes({}, 'up'));
        case 13: {
          // 'enter'
          e.preventDefault();

          if (deleteNotesIsOpen) {
            if (selectedNotes.length) {
              setDeleteNotesIsOpen(false);
              return selectedNotes.forEach((id) => {
                dispatch(deleteNote({ token }, id));
                dispatch(removeSelectedNote(id));
              });
            }

            setDeleteNotesIsOpen(false);
            return dispatch(deleteNote({ token }, activeNote));
          }
          return navigate(`/notes/${activeNote}`);
        }
        case 67: // 'c'
          e.preventDefault();
          dispatch(toggleInterfaceItem('shortcuts', false));
          return dispatch(createNote({ token, navigate }));
        case 69: // 'e'
          if (!activeNote) return;

          dispatch(toggleInterfaceItem('shortcuts', false));
          return setDeleteNotesIsOpen(true);
        case 88: // 'x'
          dispatch(toggleInterfaceItem('shortcuts', false));
          return selectedNotes.includes(activeNote)
            ? dispatch(removeSelectedNote(activeNote))
            : dispatch(addSelectedNote(activeNote));
        case 27: // 'esc'
          if (deleteNotesIsOpen) {
            return setDeleteNotesIsOpen(false);
          }

          if (selectedNotes.length) {
            return selectedNotes.forEach((id) => {
              dispatch(removeSelectedNote(id));
            });
          }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [
    activeNote,
    deleteNotesIsOpen,
    dispatch,
    getAccessTokenSilently,
    navigate,
    isAuthenticated,
    selectedNotes,
    spotlight.isOpen,
  ]);

  const routingToNoteById = useCallback(
    (id) => navigate(`/notes/${id}`),
    [navigate],
  );

  return (
    <React.Fragment>
      <DeleteNotesModal
        setDeleteNotesIsOpen={setDeleteNotesIsOpen}
        visible={deleteNotesIsOpen}
      />

      <Notes
        notes={notes}
        onNoteClick={routingToNoteById}
        login={loginWithRedirect}
        isAuthenticated={isAuthenticated}
        isLoading={fetchNotesStatus === 'loading'}
        selectedNotes={selectedNotes}
        activeNote={activeNote}
        createNote={async () => {
          // ? await getAccessTokenSilently()
          const token = isAuthenticated ? undefined : undefined;
          dispatch(createNote({ token, navigate }));
        }}
        onMouseEnter={(id) => {
          dispatch(setActiveNote(id));
        }}
      />
    </React.Fragment>
  );
}
