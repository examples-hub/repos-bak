# Roadmap

# fix

# new

# refactor

- icono部分图标scss源码存在的问题
  - 问题在于只@extend了某个元素::before伪元素的样式，如checkbox、outdent
  - 而sass编译器只支持同时@extend元素样式和::before，::after伪元素的样式，也就是输出的样式比我们期望的多了

# later

# engineering

# hard
