import type {
  EditorAppearance,
  EditorAppearanceComponentProps,
} from '../types';
import FullPage from '../ui/Appearance/FullPage';

// import Chromeless from '../ui/Appearance/Chromeless';
// import Comment from '../ui/Appearance/Comment';
// import Mobile from '../ui/Appearance/Mobile';

export default function getUiComponent(
  appearance: EditorAppearance,
):
  | React.ComponentClass<EditorAppearanceComponentProps>
  | React.FunctionComponent<EditorAppearanceComponentProps> {
  // appearance = appearance || 'comment';
  // console.log(';;appearance, ', appearance);
  const editorAppearance = appearance || 'full-page';

  switch (editorAppearance) {
    case 'full-page':
    case 'full-width':
      return FullPage;
    // case 'chromeless':
    //   return Chromeless;
    // case 'comment':
    //   return Comment;
    // case 'mobile':
    //   return Mobile;
    default:
      throw new Error(
        `Appearance '${editorAppearance}' is not supported by the editor.`,
      );
  }
}
