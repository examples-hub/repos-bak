export interface DataConsumerPluginOptions {
  allowDataConsumerMarks?: boolean;
}
