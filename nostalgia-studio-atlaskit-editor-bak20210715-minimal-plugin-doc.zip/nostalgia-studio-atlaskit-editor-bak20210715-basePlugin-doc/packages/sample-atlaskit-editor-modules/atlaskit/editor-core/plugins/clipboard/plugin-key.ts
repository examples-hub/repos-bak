import { PluginKey } from 'prosemirror-state';

export const clipboardPluginKey = new PluginKey('clipboardPlugin');
