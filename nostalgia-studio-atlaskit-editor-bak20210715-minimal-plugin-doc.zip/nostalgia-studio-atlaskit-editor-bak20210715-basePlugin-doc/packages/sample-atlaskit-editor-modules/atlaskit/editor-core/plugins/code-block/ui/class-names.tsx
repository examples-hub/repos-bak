export const codeBlockClassNames = {
  gutter: 'line-number-gutter',
  content: 'code-content',
  highlighting: 'code-highlighting',
};
