import { PluginKey } from 'prosemirror-state';
export const pluginKey = new PluginKey('codeBlockPlugin');
