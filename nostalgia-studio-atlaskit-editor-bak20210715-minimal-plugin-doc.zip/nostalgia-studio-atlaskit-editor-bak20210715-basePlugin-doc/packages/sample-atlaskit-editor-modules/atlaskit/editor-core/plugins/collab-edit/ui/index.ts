import AvatarsWithPluginState from './avatars-with-plugin-state';
export default AvatarsWithPluginState;
