import { EditorView } from 'prosemirror-view';
import React from 'react';

import { EventDispatcher } from '../../../event-dispatcher';
import messages from '../../../messages';
import WithPluginState from '../../../ui/WithPluginState';
import { PluginState, pluginKey as collabEditPluginKey } from '../plugin';
import { CollabInviteToEditProps } from '../types';
import { Avatars } from './avatars';
import { InviteToEditButton } from './invite-to-edit';
// import { InjectedIntlProps, injectIntl } from 'react-intl';


export type AvatarsWithPluginStateProps = {
  editorView?: EditorView;
  eventDispatcher?: EventDispatcher;
} & CollabInviteToEditProps;

// const AvatarsWithPluginState: React.StatelessComponent<
//   AvatarsWithPluginStateProps & InjectedIntlProps
// >
const AvatarsWithPluginState = (props) => {
  const title =
    props.intl.formatMessage(messages.inviteToEditButtonTitle) || 'AvatarTitle';

  const {
    isInviteToEditButtonSelected: selected,
    inviteToEditHandler: onClick,
    inviteToEditComponent: Component,
  } = props;

  const render = React.useCallback(
    ({ data }: { data?: PluginState }) => {
      if (!data) {
        return null;
      }

      return (
        <Avatars
          sessionId={data.sessionId}
          participants={data.activeParticipants}
        >
          <InviteToEditButton
            title={title}
            selected={selected}
            onClick={onClick}
            Component={Component}
          />
        </Avatars>
      );
    },
    [selected, onClick, Component, title],
  );

  return (
    <WithPluginState
      plugins={{ data: collabEditPluginKey }}
      render={render}
      editorView={props.editorView}
    />
  );
};

// export default injectIntl(AvatarsWithPluginState);
export default AvatarsWithPluginState;
