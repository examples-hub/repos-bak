// #region Imports
import * as React from 'react';

import type { AnnotationProviders } from '../../../plugins/annotation';
import basePlugin, { BasePluginOptions } from '../../../plugins/base';
import type { BlockTypePluginOptions } from '../../../plugins/block-type/types';
import type { CodeBlockOptions } from '../../../plugins/code-block/types';
import type { PastePluginOptions } from '../../../plugins/paste';
import type { PlaceholderPluginOptions } from '../../../plugins/placeholder';
import type { QuickInsertPluginOptions } from '../../../plugins/quick-insert';
import type { SelectionPluginOptions } from '../../../plugins/selection/types';
import type { TextFormattingOptions } from '../../../plugins/text-formatting/types';
import type { EditorPlugin } from '../../../types/editor-plugin';
import { EditorProps, PresetProvider } from '../Editor';
import { Preset } from './preset';
import type { EditorPresetProps } from './types';

// import annotationPlugin from '../../../plugins/annotation';
// import blockTypePlugin from '../../../plugins/block-type';
// import clearMarksOnChangeToEmptyDocumentPlugin from '../../../plugins/clear-marks-on-change-to-empty-document';
// import clipboardPlugin from '../../../plugins/clipboard';
// import codeBlockPlugin from '../../../plugins/code-block';
// import editorDisabledPlugin from '../../../plugins/editor-disabled';
// import fakeTextCursorPlugin from '../../../plugins/fake-text-cursor';
// import featureFlagsContextPlugin from '../../../plugins/feature-flags-context';
// import floatingToolbarPlugin from '../../../plugins/floating-toolbar';
// import hyperlinkPlugin from '../../../plugins/hyperlink';
// import pastePlugin  from '../../../plugins/paste';
// import placeholderPlugin  from '../../../plugins/placeholder';
// import quickInsertPlugin  from '../../../plugins/quick-insert';
// import selectionPlugin from '../../../plugins/selection';
// import submitEditorPlugin from '../../../plugins/submit-editor';
// import textFormattingPlugin from '../../../plugins/text-formatting';
// import typeAheadPlugin from '../../../plugins/type-ahead';
// import undoRedoPlugin from '../../../plugins/undo-redo';
// import unsupportedContentPlugin from '../../../plugins/unsupported-content';
// import widthPlugin from '../../../plugins/width';

// import { CardOptions } from '@atlaskit/editor-common';
// import { CreateUIAnalyticsEvent } from '@atlaskit/analytics-next';

// #endregion

interface EditorPresetDefaultProps {
  children?: React.ReactNode;
}

export type DefaultPresetPluginOptions = {
  paste: PastePluginOptions;
  base?: BasePluginOptions;
  blockType?: BlockTypePluginOptions;
  placeholder?: PlaceholderPluginOptions;
  textFormatting?: TextFormattingOptions;
  submitEditor?: EditorProps['onSave'];
  annotationProviders?: AnnotationProviders;
  quickInsert?: QuickInsertPluginOptions;
  codeBlock?: CodeBlockOptions;
  selection?: SelectionPluginOptions;
  cardOptions?: any;
  createAnalyticsEvent?: any;
};

/**
 * 创建编辑器内置基础插件集合的方法。
 * Note: The order that presets are added determines
 * their placement in the editor toolbar
 */
export function createDefaultPreset(
  options: EditorPresetProps & DefaultPresetPluginOptions,
) {
  const preset = new Preset<EditorPlugin>();
  // preset.add([pastePlugin, options.paste]);
  // preset.add(clipboardPlugin);
  preset.add([basePlugin, options.base] as any);
  // if (options.featureFlags?.undoRedoButtons) {
  //   preset.add(undoRedoPlugin);
  // }
  // preset.add([blockTypePlugin, options.blockType]);
  // preset.add([placeholderPlugin, options.placeholder]);
  // preset.add(clearMarksOnChangeToEmptyDocumentPlugin);

  // if (options.annotationProviders) {
  //   preset.add([annotationPlugin, options.annotationProviders]);
  // }

  // preset.add([hyperlinkPlugin, options.cardOptions]);
  // preset.add([textFormattingPlugin, options.textFormatting]);
  // preset.add(widthPlugin);
  // preset.add([quickInsertPlugin, options.quickInsert]);
  // preset.add([
  //   typeAheadPlugin,
  //   { createAnalyticsEvent: options.createAnalyticsEvent },
  // ]);
  // preset.add(unsupportedContentPlugin);
  // preset.add(editorDisabledPlugin);
  // preset.add([submitEditorPlugin, options.submitEditor]);
  // preset.add(fakeTextCursorPlugin);
  // preset.add(floatingToolbarPlugin);
  // preset.add([featureFlagsContextPlugin, options.featureFlags || {}]);
  // preset.add([selectionPlugin, options.selection]);
  // preset.add([codeBlockPlugin, options.codeBlock]);
  return preset;
}

/** 返回包含编辑器内置基础插件集合的数组 */
export function useDefaultPreset(
  props: EditorPresetProps & DefaultPresetPluginOptions,
) {
  const preset = createDefaultPreset(props);
  return [preset];
}

/** 将编辑器内置基础插件集合的数据放在provider中传下去 */
export function EditorPresetDefault(
  props: EditorPresetDefaultProps &
    EditorPresetProps &
    DefaultPresetPluginOptions,
) {
  const [preset] = useDefaultPreset(props);
  const plugins = preset.getEditorPlugins();
  return <PresetProvider value={plugins}>{props.children}</PresetProvider>;
}
