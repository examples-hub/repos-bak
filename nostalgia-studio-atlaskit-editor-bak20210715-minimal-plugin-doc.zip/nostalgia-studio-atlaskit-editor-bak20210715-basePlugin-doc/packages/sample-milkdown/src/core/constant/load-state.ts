export enum LoadState {
    Idle,
    LoadSchema,
    SchemaReady,
    LoadPlugin,
    Complete,
}
