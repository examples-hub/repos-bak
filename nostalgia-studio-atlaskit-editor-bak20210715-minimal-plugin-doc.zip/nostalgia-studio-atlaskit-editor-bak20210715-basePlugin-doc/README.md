# nostalgia studio

> a markdown-based, easy-to-read, easy-to-write and content-centric web app for data and ideas.

- **NOTE**: still under development! use at your own risk!
# overview

# license

[MIT](https://opensource.org/licenses/MIT)
