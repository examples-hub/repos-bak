import { Spinner } from './Spinner';

export { Spinner }
export default Spinner;
