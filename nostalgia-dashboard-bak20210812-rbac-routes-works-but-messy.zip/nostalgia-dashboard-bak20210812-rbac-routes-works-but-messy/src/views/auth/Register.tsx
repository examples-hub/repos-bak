import * as React from 'react';
import { Navigate } from 'react-router-dom';
import { isLoggedIn } from '../../utils/auth';

type QuickStartPageProps = {
  title?: string;
};

export function Register(props: QuickStartPageProps) {
  const { title = 'Register' } = props;

  if (isLoggedIn()) {
    return <Navigate to='/dashboard' replace />;
  }

  return (
    <div>
      <h3 className='mb-4'>{title}</h3>
      <p>A quick start page for {title}</p>
    </div>
  );
}

export default Register;
