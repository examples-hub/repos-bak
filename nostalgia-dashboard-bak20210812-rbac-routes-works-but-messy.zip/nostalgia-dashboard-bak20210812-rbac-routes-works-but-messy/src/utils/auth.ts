import { intersection } from 'lodash';
import allUserRoles from '../../config/userRoles';

export function isArrayWithLength(arr) {
  return Array.isArray(arr) && arr.length;
}

/**
 * 简单检查localStorage中是否有 userRoles 用户所属角色属性值。
 * 登录的逻辑还应该包括密码验证结果。
 */
export function isLoggedIn() {
  const curUserRoles: string | string[] = JSON.parse(
    localStorage.getItem('userRoles'),
  );

  if (!curUserRoles) return false;
  if (typeof curUserRoles === 'string') {
    return Object.keys(allUserRoles).includes(curUserRoles);
  }
  if (
    isArrayWithLength(curUserRoles) &&
    intersection(curUserRoles, Object.keys(allUserRoles)).length
  ) {
    return true;
  }

  return false;
}

/**
 * 遍历routes过滤掉没有许可的routes。
 * 没有配置access属性的默认可公开访问。
 */
export function getAllowedRoutes(routes) {
  // 当前登录用户所具有的权限，这里必须是数组
  const curUserRoles: string[] = JSON.parse(localStorage.getItem('userRoles'));

  return routes.filter(({ access }) => {
    if (!access) return true;

    const { requiredRoles } = access;
    // console.log(requiredRoles)

    if (!requiredRoles) return true;
    if (typeof requiredRoles === 'string') {
      return curUserRoles.includes(requiredRoles)
    }
    if (!isArrayWithLength(requiredRoles)) return true;
    // console.log(intersection(requiredRoles, roles))
    // 若配置的是数组，则检查当前用户的权限比较
    return intersection(curUserRoles, requiredRoles).length;
  });
}
