import { getSettingsInitialState, settingsReducer } from './settings/reducers';

export const globalInitialState = {
  settings: getSettingsInitialState(),
};

export function combiningReducer(state, action) {
  return {
    settings: settingsReducer(state.settings, action),
  };
}

export type GlobalState = ReturnType<typeof combiningReducer>;
