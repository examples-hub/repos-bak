import React, { Fragment } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { getAllowedRoutes, isLoggedIn } from '../utils/auth';
import routesConfig from '../../config/routes-test';
// import { TopNav } from 'components/common';
import RoutesAllowed from './RoutesAllowed';
import FullLayout from '../layouts/FullLayout';
import NotFound from '../pages/exception/404';
import RoutesUrlLists from '../pages/about/routes-url-lists';
import Starter from '../views/dashboard-starter';

function PrivateRoutes() {
  let allowedRoutes = [];

  if (!isLoggedIn()) {
    return <Navigate to='/' replace />;
  }

  allowedRoutes = getAllowedRoutes(routesConfig);
  console.log(';;allowedRoutes, ', allowedRoutes);

  return (
    <Routes>
      {/* <Route path='/' element={<RoutesUrlLists title='path: dashboard/' />} /> */}
      <Route path='/' element={<Starter />} />

      {allowedRoutes.map((route) => {
        const { path, component: Component, children, ...rest } = route;

        return (
          <Route
            {...rest}
            key={path}
            path={`${path}`}
            element={<Component>{children}</Component>}
          />
        );
      })}

      <Route path='*' element={<RoutesUrlLists title='/dashboard/*' />} />
      {/* {isAddNotFound && <Route path='*' element={<NotFound />} />} */}
    </Routes>
  );
}

export default PrivateRoutes;
