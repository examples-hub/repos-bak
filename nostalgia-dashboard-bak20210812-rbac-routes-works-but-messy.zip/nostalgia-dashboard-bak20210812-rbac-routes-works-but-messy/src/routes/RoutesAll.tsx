import React, { memo } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import AuthRedirect from './AuthRedirect';
import FullLayout from '../layouts/FullLayout';
import PrivateRoutes from './RoutesPrivate';

function RoutesWithAuth() {
  return (
    <Routes>
      <Route path='dashboard' element={<FullLayout />}>
        <Route path='*' element={<PrivateRoutes />} />
      </Route>

      {/* 无需登录就可查看的公共页面，且不会出现在侧边菜单 */}
      <Route path='*' element={<AuthRedirect />} />
    </Routes>
  );
}

// export default memo(RoutesWithAuth);
export default RoutesWithAuth;
