import React, { Fragment } from 'react';
import { Route, Routes } from 'react-router-dom';
import { Login, Register, ForgotPassword, LandingPage } from '../views/auth';

/**
 * 这里的公共routes不是从配置文件读取，而是直接导入了react组件，可用于注册登录等公共页面；
 * routes配置文件中也有无需权限的公共routes，其中的公共routes会出现在侧边菜单，而这里不会；
 */
function PublicRoutes() {
  return (
    <Routes>
      <Route path='register' element={<Register />} />
      <Route path='login' element={<Login />} />
      <Route path='pwd' element={<ForgotPassword />} />
      <Route path='*' element={<LandingPage />} />
    </Routes>
  );
}

export default PublicRoutes;
