import React, { memo } from 'react';
import { Routes, Route } from 'react-router-dom';
import NotFound from '../pages/exception/404';

/*
 * This is the route utility component used for generating
 * routes and child routes it only requires routes array and basePath
 */
// function RoutesAllowed({ routes, basePath, isAddNotFound }) {
function RoutesAllowed({ routes, isAddNotFound }) {
  return (
    <React.Fragment>
      {/* <Routes> */}
      {routes.map((route) => {
        const { path, component: Component, children, ...rest } = route;

        return (
          <Route
            {...rest}
            key={path}
            path={`${path}`}
            element={<Component>{children}</Component>}
          />
        );
      })}

      {isAddNotFound && <Route path='*' element={<NotFound />} />}
      {/* </Routes> */}
    </React.Fragment>
  );
}

// export default memo(RoutesAllowed);
export default RoutesAllowed;
