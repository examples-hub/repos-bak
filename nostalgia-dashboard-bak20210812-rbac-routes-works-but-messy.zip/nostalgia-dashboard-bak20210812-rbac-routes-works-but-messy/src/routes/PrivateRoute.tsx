import * as React from 'react';
import { Route, Navigate, useLocation } from 'react-router-dom';
import { AuthenticationService } from '../jwt/_services';

// requiredRoles: 值为字符串时，比较优先级；值为数组时，已登录用户的role必须匹配数组元素之一

// 创建Route时检查用户名只是最基本的一个实现
export function PrivateRoute({ component: Component, ...rest }) {
  // const location = useLocation();
  const location = window.location;

  const currentUser = AuthenticationService.currentUserValue;

  // return user ? <Comp {...props} /> : <Home />;
  return currentUser ? (
    <Route element={<Component {...rest} />} />
  ) : (
    <Navigate
      to='/authentication/Login'
      replace={true}
      state={{ from: location }}
    />
  );
}

export default PrivateRoute;
