import Login from "../views/auth/Login"

const AuthRoutes = [
  { path: '/auth/Login', name: 'Login', icon: 'mdi mdi-account-key', component: Login }
];
export default AuthRoutes;
