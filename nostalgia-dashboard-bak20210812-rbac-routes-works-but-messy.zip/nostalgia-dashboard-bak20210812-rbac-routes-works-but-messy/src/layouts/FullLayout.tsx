import React, { Suspense, useEffect, useState } from 'react';
import { Navigate, Route, Routes, useLocation, Outlet } from 'react-router-dom';

import routes, { RoutesConfigType } from '../../config/routes';
import Spinner from '../components/spinner';
import { useGlobalContext } from '../store/global-context';
import RoutingPagesErrorBoundary from '../views/exception/RoutingPagesErrorBoundary';
import Customizer from '../views/settings-customizer/Customizer';
import Footer from './footer';
import Header from './header';
import { tryToGetLazyImportedComp } from './maybe-dynamic-components';
import Sidebar from './sidebar';
import { isLoggedIn } from '../utils/auth';

const FullLayout = (props) => {
  const [width, setWidth] = useState(window.innerWidth);

  const {
    state: { settings },
  } = useGlobalContext();

  useEffect(() => {
    const updateDimensions = () => {
      const element = document.getElementById('main-wrapper');
      if (!element) return;
      setWidth(window.innerWidth);
      switch (settings.activeSidebarType) {
        case 'full':
        case 'iconbar':
          // if (width < 1170) {
          if (width < 940) {
            element.setAttribute('data-sidebartype', 'mini-sidebar');
            element.classList.add('mini-sidebar');
          } else {
            element.setAttribute(
              'data-sidebartype',
              settings.activeSidebarType,
            );
            element.classList.remove('mini-sidebar');
          }
          break;

        case 'overlay':
          // if (width < 767) {
          if (width < 700) {
            element.setAttribute('data-sidebartype', 'mini-sidebar');
          } else {
            element.setAttribute(
              'data-sidebartype',
              settings.activeSidebarType,
            );
          }
          break;

        default:
      }
    };
    if (document.readyState === 'complete') {
      updateDimensions();
    }
    window.addEventListener('load', updateDimensions.bind(null));
    window.addEventListener('resize', updateDimensions.bind(null));
    return () => {
      window.removeEventListener('load', updateDimensions.bind(null));
      window.removeEventListener('resize', updateDimensions.bind(null));
    };
  }, [settings.activeSidebarType, width]);

  // console.log(';;isLoggedIn(), ', isLoggedIn());
  if (!isLoggedIn()) {
    // 若未登录，则不可查看
    return <Navigate to='/' replace />;
  }

  return (
    <div
      id='main-wrapper'
      dir={settings.activeDir}
      data-theme={settings.activeTheme}
      data-layout={settings.activeThemeLayout}
      data-sidebartype={settings.activeSidebarType}
      data-sidebar-position={settings.activeSidebarPos}
      data-header-position={settings.activeHeaderPos}
      data-boxed-layout={settings.activeLayout}
    >
      <Header />

      {/* <Sidebar {...props} routes={routes} /> */}

      {/* 基于react-router在不同url展示不同的页面组件 */}
      <div className='page-wrapper d-block'>
        {/* <div className='page-content container-fluid'>
          <RoutingPagesErrorBoundary>
            <Suspense fallback={<Spinner />}> */}
        <Outlet />
        {/* </Suspense>
          </RoutingPagesErrorBoundary>
        </div>
        <Footer /> */}
      </div>

      {/* 右侧浮动配置面板 */}
      {/* <Customizer /> */}
    </div>
  );
};

export default FullLayout;
