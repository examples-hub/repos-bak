import { QuickStartPage } from '../starter/quickstart';

export default QuickStartPage;
