import DashboardStarter from '../views/dashboard-starter/DashboardStarter'

export default DashboardStarter;
