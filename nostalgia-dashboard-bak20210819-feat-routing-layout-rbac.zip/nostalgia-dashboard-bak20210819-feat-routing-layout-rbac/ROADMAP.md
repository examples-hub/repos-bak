# roadmap for dashboard

# todo

# fix

# new

# discuss

- 各个path、各个嵌套层级的404路由跳转如何实现
  - config/routes.ts配置部分只定义了开发者需要的routes

# faq

## 左侧边栏中若某一项文字过长，则所有项的左边显示效果就是不对齐的，过长项会偏左
- a1: 提示用户修改过长项的文字不超过18字，否则自动裁剪文字，将中间部分显示为省略号
- a1: 侧边栏显示水平滚动条
- a2: 自动加宽侧边栏宽度
