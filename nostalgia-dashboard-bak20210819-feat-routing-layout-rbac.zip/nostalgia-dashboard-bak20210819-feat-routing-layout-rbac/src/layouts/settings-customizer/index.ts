import SetttingsCustomizer from './SetttingsCustomizer';
export { SetttingsCustomizer };
export default SetttingsCustomizer;
