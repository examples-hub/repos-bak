import * as React from 'react';
import { NavbarBrand } from 'reactstrap';

export function LogoIconText(props) {
  const {
    logoText,
    activeLogoBg,
    handleToggleWholeSidebar,
    handleToggleHeaderMenuContents,
    logodarkicon,
    logolighticon,
  } = props;

  return (
    <div className='navbar-header' id='logobg' data-logobg={activeLogoBg}>
      {/* 当视口宽度 < 768px时，左边只显示汉堡菜单，logo会显示在导航条中间 */}
      <span
        className='nav-toggler d-block d-md-none cursor-pointer'
        onClick={handleToggleWholeSidebar}
      >
        <i className='fa fa-bars' />
      </span>

      {/* logo图片和title */}
      <NavbarBrand href='/'>
        <b className='logo-icon'>
          <img src={logodarkicon} alt='homepage' className='dark-logo' />
          <img src={logolighticon} alt='homepage' className='light-logo' />
        </b>
        <span className='logo-text'>{logoText}</span>
      </NavbarBrand>

      {/* 当视口宽度 < 768px时，右边显示更多...图标 */}
      <span
        className='topbartoggler d-block d-md-none cursor-pointer'
        onClick={handleToggleHeaderMenuContents}
      >
        <i className='fa fa-ellipsis-h' />
      </span>
    </div>
  );
}

export default LogoIconText;
