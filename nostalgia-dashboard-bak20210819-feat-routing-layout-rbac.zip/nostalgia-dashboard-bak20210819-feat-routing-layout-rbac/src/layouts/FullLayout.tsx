import React, { Suspense, useEffect, useMemo, useState } from 'react';
import {
  Navigate,
  Outlet,
  Route,
  Routes,
  useLocation,
  useNavigate,
} from 'react-router-dom';

import Spinner from '../components/feedback/spinner';
import { useGlobalContext } from '../store/global-context';
import { isValidUserRoles } from '../utils/auth';
import RoutingPagesErrorBoundary from '../views/exception/RoutingPagesErrorBoundary';
import Footer from './footer';
import Header from './header';
import SetttingsCustomizer from './settings-customizer';
import Sidebar from './sidebar';

/**
 * 整个App的整体布局组件，左中右分别是sidebar、page-contents、settings-side-panel。
 */
const FullLayout = (props) => {
  const { routes } = props;

  const { pathname } = useLocation();
  const navigate = useNavigate();

  const {
    state: { settings, auth },
    dispatch,
  } = useGlobalContext();
  const [width, setWidth] = useState(window.innerWidth);

  useEffect(() => {
    let isMounted = true;

    /**
     * 当global store中样式布局相关属性值变化时，会自动更新本组件最外层data-*的值；
     * 因为整体布局css大量依赖data-*，所以要更新用到过的data-属性值，没用到的可以不用更新；
     * 大多数data-*会通过state直接更新，这里只处理需要转换的情况。
     */
    const updateDimensions = () => {
      const element = document.getElementById('main-wrapper');

      if (!element) return;
      if (isMounted) {
        setWidth(window.innerWidth);
      }

      switch (settings.activeSidebarType) {
        case 'full':
        case 'iconbar':
          // if (width < 1170) {
          if (width < 940) {
            element.setAttribute('data-sidebartype', 'mini-sidebar');
            element.classList.add('mini-sidebar');
          } else {
            element.setAttribute(
              'data-sidebartype',
              settings.activeSidebarType,
            );
            element.classList.remove('mini-sidebar');
          }
          break;

        case 'overlay':
          // if (width < 767) {
          if (width < 700) {
            element.setAttribute('data-sidebartype', 'mini-sidebar');
          } else {
            element.setAttribute(
              'data-sidebartype',
              settings.activeSidebarType,
            );
          }
          break;

        default:
      }
    };

    if (document.readyState === 'complete') {
      updateDimensions();
    }
    window.addEventListener('load', updateDimensions);
    window.addEventListener('resize', updateDimensions);

    return () => {
      isMounted = false;
      window.removeEventListener('load', updateDimensions);
      window.removeEventListener('resize', updateDimensions);
    };
  }, [settings.activeSidePanelType, settings.activeSidebarType, width]);

  // useEffect(() => {
  //   const user = JSON.parse(localStorage.getItem('curuser'));
  //   if (user?.token) {
  //     // dispatch(profileFetch(token));
  //     console.log(';;FullLayout-curuser, ', user);
  //   }
  // }, [dispatch]);

  const memoedResultJsx = useMemo(
    () => (
      <div
        id='main-wrapper'
        dir={settings.activeDir}
        data-theme={settings.activeTheme}
        data-layout={settings.activeThemeLayout}
        data-sidebartype={settings.activeSidebarType}
        data-sidebar-position={settings.activeSidebarPos}
        data-side-panel-type={settings.activeSidePanelType}
        data-side-panel-position={settings.activeSidePanelPos}
        data-header-position={settings.activeHeaderPos}
        data-boxed-layout={settings.activeLayout}
      >
        <Header />

        <Sidebar {...props} routes={routes} />

        {/* 基于react-router在不同url展示不同的页面组件 */}
        <div
          className={`page-wrapper d-block ${
            settings.activeSidePanelType === 'dock' &&
            !settings.isSidePanelShown
              ? 'mr-0'
              : ''
          }`}
        >
          <div className='page-content container-fluid'>
            <RoutingPagesErrorBoundary>
              <Suspense fallback={<Spinner />}>
                <Outlet />
              </Suspense>
            </RoutingPagesErrorBoundary>
          </div>
          <Footer />
        </div>

        {/* 右侧浮动配置面板 */}
        <SetttingsCustomizer />
      </div>
    ),
    [
      props,
      routes,
      settings.activeDir,
      settings.activeHeaderPos,
      settings.activeLayout,
      settings.activeSidePanelPos,
      settings.activeSidePanelType,
      settings.activeSidebarPos,
      settings.activeSidebarType,
      settings.activeTheme,
      settings.activeThemeLayout,
      settings.isSidePanelShown,
    ],
  );

  if (!auth.isAuthenticated || !isValidUserRoles()) {
    // 若未登录，则不可查看内容，跳转到登录页
    return <Navigate to='/login' replace />;
    // navigate('/login', { replace: true });
  }
  if (['/dashboard', '/dashboard/'].includes(pathname)) {
    console.log(';;FullLayout, redirect /dashboard to /dashboard/basic');
    return <Navigate to='/dashboard/basic' replace />;
    // navigate('/dashboard/basic', { replace: true });
  }

  // 整个App最外层div，id是main-wrapper
  return memoedResultJsx;
};

export default FullLayout;
