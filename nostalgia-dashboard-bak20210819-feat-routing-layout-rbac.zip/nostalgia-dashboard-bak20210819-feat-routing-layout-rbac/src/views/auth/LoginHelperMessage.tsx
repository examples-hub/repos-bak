import * as React from 'react';
import { Card, CardBody } from 'reactstrap';

type LoginHelperMessageProps = {
  title?: string;
};

export function LoginHelperMessage(props: LoginHelperMessageProps) {
  const { title = 'ForgotPassword' } = props;
  return (
    <div className='pt-5 text-muted'>
      <p>帐号1: admin &nbsp; 密码: 111111 说明: 管理员帐号</p>
      <p>
        帐号2: test &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 密码: 111111 说明: 普通用户
      </p>
    </div>
  );
}

export default LoginHelperMessage;
