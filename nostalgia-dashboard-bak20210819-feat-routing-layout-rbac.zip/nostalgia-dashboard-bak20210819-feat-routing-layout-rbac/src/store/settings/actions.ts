import {
  DIRECTION,
  HEADER_POSITION,
  LAYOUT,
  LOGO_BG,
  NAVBAR_BG,
  RESET_TO_DEFAULT_LAYOUT,
  SIDEBAR_BG,
  SIDEBAR_POSITION,
  SIDEBAR_TYPE,
  SIDE_PANEL_POSITION,
  SIDE_PANEL_TYPE,
  THEME,
} from '../actions-constants';

export const resetToDefaultLayoutSettings = () => {
  return { type: RESET_TO_DEFAULT_LAYOUT };
};

export const setLogoBg = (payload) => {
  return {
    type: LOGO_BG,
    payload,
  };
};

export const setNavbarBg = (payload) => {
  return {
    type: NAVBAR_BG,
    payload,
  };
};

export const setSidebarBg = (payload) => {
  return {
    type: SIDEBAR_BG,
    payload,
  };
};

export const setTheme = (payload) => {
  return {
    type: THEME,
    payload,
  };
};

export const setDir = (payload) => {
  return {
    type: DIRECTION,
    payload,
  };
};

export const setSidebarPos = (payload) => {
  return {
    type: SIDEBAR_POSITION,
    payload,
  };
};

export const setHeaderPos = (payload) => {
  return {
    type: HEADER_POSITION,
    payload,
  };
};

export const setLayout = (payload) => {
  return {
    type: LAYOUT,
    payload,
  };
};

export const setSidebarType = (payload) => {
  return {
    type: SIDEBAR_TYPE,
    payload,
  };
};
export const setSidePanelType = (payload) => {
  return {
    type: SIDE_PANEL_TYPE,
    payload,
  };
};

export const setSidePanelPos = (payload) => {
  return {
    type: SIDE_PANEL_POSITION,
    payload,
  };
};
