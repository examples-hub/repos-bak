import defaultSettings from '../../../config/defaultSettings';
import type {
  I18nDirType,
  SidebarType,
  ThemeType,
} from '../../common/types/ui-layout';
import {
  DIRECTION,
  HEADER_POSITION,
  LAYOUT,
  LOGO_BG,
  NAVBAR_BG,
  RESET_TO_DEFAULT_LAYOUT,
  SIDEBAR_BG,
  SIDEBAR_POSITION,
  SIDEBAR_TYPE,
  SIDE_PANEL_POSITION,
  SIDE_PANEL_TYPE,
  THEME,
  TOGGLE_SETTINGS_COG_BUTTON,
  TOGGLE_SIDEBAR,
  TOGGLE_SIDE_PANEL,
} from '../actions-constants';

export type SettingsStateType = {
  logoText?: string;
  isSidebarShown: boolean;
  isSidePanelShown: boolean;
  isSettingsCogButtonShown?: boolean;
  activeSidebarType?: SidebarType;
  activeSidebarPos?: 'fixed' | 'absolute';
  activeSidePanelType?: 'overlay' | 'dock' | 'absolute';
  activeSidePanelPos?: 'fixed' | 'absolute';
  activeHeaderPos?: 'fixed' | 'absolute';
  activeLayout?: 'full' | 'boxed';
  activeThemeLayout?: 'vertical' | 'horizontal';
  activeDir?: I18nDirType;
  activeTheme?: ThemeType;
  activeLogoBg?: string;
  activeNavbarBg?: string;
  activeSidebarBg?: string;
};

export function getSettingsInitialState(): SettingsStateType {
  return {
    logoText: String(defaultSettings.title) ?? 'Nostalgia',

    isSidebarShown: true,
    isSidePanelShown: false,
    isSettingsCogButtonShown: true,

    activeSidebarType: 'full',
    activeSidebarPos: 'fixed',
    activeSidePanelType: 'overlay',
    activeSidePanelPos: 'fixed',
    activeHeaderPos: 'fixed',
    activeLayout: 'full',
    activeThemeLayout: 'vertical',
    activeDir: 'ltr',
    activeTheme: 'light',
    activeLogoBg: 'skin6',
    activeNavbarBg: 'skin6',
    activeSidebarBg: 'skin6',
  };
}

export function settingsReducer(
  state = getSettingsInitialState(),
  action,
): SettingsStateType {
  switch (action.type) {
    case RESET_TO_DEFAULT_LAYOUT:
      return getSettingsInitialState();
    case LOGO_BG:
      return {
        ...state,
        activeLogoBg: action.payload,
      };
    case NAVBAR_BG:
      return {
        ...state,
        activeNavbarBg: action.payload,
      };
    case SIDEBAR_BG:
      return {
        ...state,
        activeSidebarBg: action.payload,
      };
    case THEME:
      return {
        ...state,
        activeTheme: action.payload,
      };
    case DIRECTION:
      return {
        ...state,
        activeDir: action.payload,
      };
    case LAYOUT:
      return {
        ...state,
        activeLayout: action.payload,
      };
    case HEADER_POSITION:
      return {
        ...state,
        activeHeaderPos: action.payload,
      };
    case SIDEBAR_POSITION:
      return {
        ...state,
        activeSidebarPos: action.payload,
      };
    case SIDEBAR_TYPE:
      return {
        ...state,
        activeSidebarType: action.payload,
      };
    case SIDE_PANEL_TYPE:
      return {
        ...state,
        activeSidePanelType: action.payload,
      };
    case SIDE_PANEL_POSITION:
      return {
        ...state,
        activeSidePanelPos: action.payload,
      };
    case TOGGLE_SIDEBAR:
      return {
        ...state,
        isSidebarShown: !state.isSidebarShown,
      };
    case TOGGLE_SIDE_PANEL:
      return {
        ...state,
        isSidePanelShown: !state.isSidePanelShown,
      };
    case TOGGLE_SETTINGS_COG_BUTTON:
      return {
        ...state,
        isSettingsCogButtonShown: !state.isSettingsCogButtonShown,
      };
    default:
      return state;
  }
}

export default settingsReducer;
