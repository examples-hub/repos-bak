# react dashboard app

# overview

# usage

# notes

- heavily inspired by [Ant Design Pro](https://github.com/ant-design/ant-design-pro)

- this dashboard started as a fork of [wrappixel/xtreme-react-lite](https://github.com/wrappixel/xtreme-react-lite)
  - wrappixel free version [live demo](https://wrappixel.com/demos/free-admin-templates/xtreme-reactadmin-lite/main/#/dashboard)
