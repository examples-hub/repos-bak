import Fulllayout from '../layouts/fulllayout.jsx';

const indexRoutes = [{ path: '/', name: 'Starter', component: Fulllayout }];

export default indexRoutes;
