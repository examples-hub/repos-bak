import './index.css';
import './assets/scss/style.scss';

import * as React from 'react';
import {
  HashRouter,
  Route,
  BrowserRouter as Router,
  Switch,
} from 'react-router-dom';

import indexRoutes from './routes/index.jsx';

export function App() {
  return (
    <Router>
      <Switch>
        {indexRoutes.map((prop, key) => {
          return (
            <Route path={prop.path} key={key} component={prop.component} />
          );
        })}
      </Switch>
    </Router>
  );
}

export default App;
