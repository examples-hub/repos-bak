import { Datastore } from '../datastore';

export interface IPersistenceOptions {
  db?: Datastore | null;
  nodeWebkitAppName?: string;
  afterSerialization?: ((str: string) => string) | null;
  beforeDeserialization?: (str: string) => string;
  corruptAlertThreshold?: number;
}

export class PersistenceOptions {
  public db?: Datastore | null;
  /** @deprecated use if you are using NeDB from within a Node Webkit app */
  public nodeWebkitAppName?: string | null;
  /** use to transform data after it was serialized and before it is written to disk.
   * - Can be used for example to encrypt data before writing database to disk.
   **/
  public afterSerialization?: ((str: string) => string) | null;
  /** use to transform data after load to memory and before deserialized.
   * - Make sure to include both and not just one or you risk data loss.
   **/
  public beforeDeserialization?: ((str: string) => string) | null;
  /** between 0 and 1, defaults to 10%.
   * - 0 means you don't tolerate any corruption, 1 means you don't care.
   * - NeDB will refuse to start if more than this percentage of the datafile is corrupt.
   */
  public corruptAlertThreshold?: number | null;

  constructor(options?: IPersistenceOptions) {
    if (options) {
      this.db = options.db ?? null;
      this.nodeWebkitAppName = options.nodeWebkitAppName ?? null;
      this.afterSerialization = options.afterSerialization ?? null;
      this.beforeDeserialization = options.beforeDeserialization ?? null;
      this.corruptAlertThreshold = options.corruptAlertThreshold ?? 0.1;
    }
  }
}
