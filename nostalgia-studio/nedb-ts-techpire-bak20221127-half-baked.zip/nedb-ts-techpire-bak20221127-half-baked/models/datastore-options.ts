import { StringUtil } from '../utils';
import {
  PersistenceOptions,
  type IPersistenceOptions,
} from './persistence-options';

export interface IDataStoreOptions extends IPersistenceOptions {
  /** autoload file */
  autoload?: boolean;
  compareStrings?: Function;
  /** path */
  filename?: string | null;
  inMemoryOnly?: boolean;
  onLoad?: ((error: any) => void) | null;
  timestampData?: boolean;
}

export class DatastoreOptions extends PersistenceOptions {
  /** default false.
   * - if used, the database will automatically be loaded from the datafile upon creation
   * - Any command issued before load is finished is buffered and will be executed when load is done. */
  public autoload?: boolean = false;
  /** default null.
   * - if you use autoloading, this is the handler called after the loadDatabase.
   * - If you use autoloading without specifying this handler, and an error happens during load, an error will be thrown. */
  public onload?: ((error: any) => void) | null;
  /** path to the file where the data is persisted.
   * - If left blank, the datastore is automatically considered in-memory only.
   * - It cannot end with a `~` which is used in the temporary files NeDB uses to perform crash-safe writes. */
  public filename?: string | null;
  /** default false */
  public inMemoryOnly?: boolean = false;
  /** default false.
   * - timestamp the insertion and last update of all documents, with the fields createdAt and updatedAt.
   * - useful for testing */
  public timestampData?: boolean = false;
  /** compares strings a and b and return -1, 0 or 1.
   * - If specified, it overrides default string comparison which is not well adapted to non-US characters in particular accented letters.
   * - Native `localCompare` will most of the time be the right choice */
  public compareStrings?: Function | null;

  constructor(options?: IDataStoreOptions) {
    super(options);

    if (options) {
      if (StringUtil.IsNullOrWhiteSpace(this.filename)) {
        this.filename = options.filename ?? null;
        this.inMemoryOnly = false;
      } else {
        this.filename = options.filename;
        this.inMemoryOnly = options.inMemoryOnly || false;
      }

      this.autoload = options.autoload ?? false;
      this.compareStrings = options.compareStrings ?? null;
      this.filename = options.filename ?? null;
      this.onload = options.onLoad ?? null;
      this.timestampData = options.timestampData ?? false;
    }
  }
}
