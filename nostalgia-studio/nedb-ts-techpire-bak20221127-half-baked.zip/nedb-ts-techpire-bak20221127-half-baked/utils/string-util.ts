/** static utility class for string */
export class StringUtil {
  /**
   * Returns true or false based on whether or not the string is empty, whitespace, or otherwise null/undefined.
   * Accepting no parameter seems pointless, however, it is the only way to allow null or undefined checks.
   *
   * @param string? String to test
   * @return boolean
   */
  public static IsNullOrWhiteSpace(val?: string | null): boolean {
    return val === undefined || val === null || val.trim().length === 0;
  }
}
