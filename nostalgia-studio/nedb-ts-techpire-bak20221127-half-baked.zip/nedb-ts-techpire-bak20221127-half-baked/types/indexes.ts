export type IndexCtorOptions = {
  /** name of the field to index. Use the dot notation to index a field in a nested document. */
  fieldName: string;
  /** default false. Note that a unique index will raise an error if you try to index two documents for which the field is not defined. */
  unique?: boolean;
  /** default false. don't index documents for which the field is not defined.
   * - Use this option along with "unique" if you want to accept multiple documents for which it is not defined.
   */
  sparse?: boolean;
  /** if set, the created index is a TTL (time to live) index, that will automatically remove documents
   * - Documents where the indexed field is not specified or not a Date object are ignored
   */
  expireAfterSeconds?: number;
};
