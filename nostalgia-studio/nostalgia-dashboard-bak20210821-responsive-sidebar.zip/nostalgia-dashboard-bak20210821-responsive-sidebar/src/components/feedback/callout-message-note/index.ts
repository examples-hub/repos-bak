import { CalloutMessageNote } from './CalloutMessageNote';

export { CalloutMessageNote };
export default CalloutMessageNote;
