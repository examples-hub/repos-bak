import { Model } from './model';

export { Model };
export default Model;
