# linvodb

# overview

- this project is a fork of linvodb
  - for nodejs usage
  - deps updated

- https://github.com/Ivshti/linvodb3 /MIT
  - LinvoDB is based on NeDB, the most significant core change is that it uses LevelUP as a back-end, meaning it doesn't have to keep the whole dataset in memory.
# usage

# roadmap

## dev-to-list

- merge各个仓库的pr
# testing
- 迁移web版tests

## 待改进的测试

## tests-failed

# more
