import { Box } from '@mui/material';

export default function Tokens(): JSX.Element {
  return (
    <Box mt={5}>
      <h1>Tokens</h1>
    </Box>
  );
}
