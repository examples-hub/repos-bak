export default function VerticalPlayer() {
  return <div className='vertical-player'></div>;
}
