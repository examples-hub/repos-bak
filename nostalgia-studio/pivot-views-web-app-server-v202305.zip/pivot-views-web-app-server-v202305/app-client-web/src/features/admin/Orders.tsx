/**
 *
 * Orders needs special view, we want to see oneline status as well as certain actions
 * maybe we can enrich generic editor via props, think
 */
export default function Orders() {
  return (
    <div>
      <h1>Orders</h1>
    </div>
  );
}
