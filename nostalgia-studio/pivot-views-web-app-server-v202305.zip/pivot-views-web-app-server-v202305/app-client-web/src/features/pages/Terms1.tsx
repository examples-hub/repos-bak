export default function Terms() {
  return (
    <div>
      <h1>Terms</h1>
    </div>
  );
}
