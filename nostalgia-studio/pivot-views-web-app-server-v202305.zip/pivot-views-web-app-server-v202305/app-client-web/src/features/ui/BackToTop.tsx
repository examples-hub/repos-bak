import Fab from '@mui/material/Fab';

export default function FabBackToTop() {
  return (
    <div>
      <Fab />
    </div>
  );
}
