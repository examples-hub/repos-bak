export default function Consent(): JSX.Element {
  return (
    <div>
      <h1>Consent Banner</h1>
    </div>
  );
}
