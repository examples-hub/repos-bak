import React from 'react';

export function Spacer() {
  return <div style={{ flex: '1 0 0' }} />;
}

export default Spacer;
