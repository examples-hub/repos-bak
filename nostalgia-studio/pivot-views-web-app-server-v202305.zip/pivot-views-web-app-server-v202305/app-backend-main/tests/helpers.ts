jest.mock('../src/shared/logger');

export function beforeAllHook() {
  // ...
}
