import test from 'tape';

test('simple test', (t) => {
  t.plan(1);
  t.ok('this test passes');
});
