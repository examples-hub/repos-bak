export { insertColumn } from './insertColumn';
export { insertRow } from './insertRow';
export { insertTable } from './insertTable';
export { removeColumn } from './removeColumn';
export { removeRow } from './removeRow';
export { removeTable } from './removeTable';
