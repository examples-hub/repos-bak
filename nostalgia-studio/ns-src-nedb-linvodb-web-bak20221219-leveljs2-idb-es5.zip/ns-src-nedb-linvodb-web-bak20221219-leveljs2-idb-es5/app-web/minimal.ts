import leveljs from 'level-js';

import { Model as LinvoDB } from '../src';

console.log(';; LinvoDB ', LinvoDB);

// Initialize the default store to level-js - which is a JS-only store which will work without recompiling in NW.js/Electron
// @ts-expect-error fix-types
LinvoDB.defaults.store = { db: leveljs }; // Comment out to use LevelDB instead of level-js
// @ts-expect-error fix-types; Set dbPath - this should be done explicitly and will be the dir where each model's store is saved
// LinvoDB.dbPath = process.cwd();
LinvoDB.dbPath = './lv-path'; // path实参 对应于 idb的objectStore名称

let Doc;
// @ts-expect-error fix-types
// Doc = new LinvoDB('lvDoc', {});

Doc = new LinvoDB('testDb', {
  schema: {
    name: { index: true, unique: true, sparse: true },
    age: { index: true },
    department: { index: false },
    address: { city: { index: true } },
  },
});
console.log(';; Doc ', Doc);

// Construct a single document and then save it
// const doc1 = new Doc();
// const doc1 = new Doc({ aa: 5, now: new Date(), test: 'test-str' });
// doc1.bb = 13; // you can modify the doc
// doc1.save((err) => {
//   console.log(';; save-cb-err ', err, doc1);
// });

// you can use the .insert method to insert one or more documents
// Doc.insert({ aa: 3 }, (err, newDoc) => {
//   console.log(';; insert-cb ', newDoc);
// });

// Doc.insert([{ a: 3 }, { a: 42 }], (err, newDocs) => {
//   // Two documents were inserted in the database
//   // newDocs is an array with these documents, augmented with their _id
//   // If there's an unique constraint on 'a', this will fail, and no changes will be made to the DB
//   // err is a 'uniqueViolated' error
//   Doc.find({}, (err, docs) => {
//     console.log(';; find ', docs);
//   });
// });

// Replace a document by another; use { $set: { aa:55 }} to update
// Doc.update({ aa: 5 }, { aa: 55 }, { upsert: true }, (err, numReplaced) => {
//   console.log(';; numReplaced ', numReplaced); //1
//   Doc.find({}, (err, docs) => {
//     console.log(';; find-u ', docs);
//   });
// });

// Doc.remove({ aa: 3 }, {}, (err, numRemoved) => {
//   console.log(';; removed ', numRemoved); //1
//   Doc.find({}, (err, docs) => {
//     // 👀 ensure data is persisted before find;
//     console.log(';; find-r ', docs);
//   });
// });
