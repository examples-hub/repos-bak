export const log = () => console.log(process.argv);
export default log;
