import log from 'package-a';
log();
