# monorepo-quickstart-es6

- quickstart example monorepo using npm workspaces

## overview

## demo

## note

## todo
