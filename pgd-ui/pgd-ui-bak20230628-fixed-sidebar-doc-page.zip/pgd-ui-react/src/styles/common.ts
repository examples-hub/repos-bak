import { css } from '@linaria/core';

export const cardBoxCss = css`
  padding: 24px;
  margin-bottom: 24px;
  border-radius: 10px;
  background-color: #ffffff;
`;
