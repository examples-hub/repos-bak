export { cardBoxCss } from './common';
