export { DocPage } from './doc-page';
