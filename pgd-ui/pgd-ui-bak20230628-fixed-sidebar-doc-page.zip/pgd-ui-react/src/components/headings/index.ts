export {
  Heading1,
  Heading2,
  Heading3,
  Heading4,
  HeadingLevel,
  Heading,
} from './heading-pgd';
