// import * as React from 'react';
// import ReactDOM from 'react-dom';
// import App from './App';
// // import log from 'package-a';

// // import './index.css';

// // log();

// ReactDOM.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>,
//   document.getElementById('root'),
// );
