import { lazy } from 'react';

// import type { RoutesConfigType } from './routes';

/** 通过React.lazy懒加载所有route对应的组件 */
// export function lazyImportComponents(routes: RoutesConfigType) {
export function lazyImportComponents(routes) {
  routes.forEach((route1, key) => {
    tryLazyImportComp(route1);

    if (route1.routes && route1.routes.length) {
      route1.routes.forEach((route2) => {
        tryLazyImportComp(route2);

        if (route2.routes && route2.routes.length) {
          route2.routes.forEach((route3) => {
            tryLazyImportComp(route3);
          });
        }
      });
    }
  });

  return routes;
}

/** 动态导入react组件，直接mutate修改当前route对象 */
function tryLazyImportComp(curRoute: any) {
  if (
    curRoute.navlabel ||
    curRoute.redirect ||
    curRoute.path.startsWith('http')
  ) {
    return;
  }

  let MaybeDynamicComp: any = curRoute.component;

  if (typeof curRoute.component === 'string') {
    const DynamicComp = lazy(
      () => import(`../pages/${curRoute.component}.tsx`),
      // .catch(
      // todo 生产环境下隐藏错误页面
      //   (err) => import(`./views/exception/DynamicImportErrorPage`),
      // ),
    );

    // console.log('curRoute.component, ', curRoute.component, Comp);

    MaybeDynamicComp = DynamicComp;
    curRoute.component = MaybeDynamicComp;
  }

  // return curRoute;
}

// export const Starter = lazy(() => import('../pages/starter/quickstart'));
