import * as React from 'react';
import { Route, Navigate, useLocation } from 'react-router-dom';
import { AuthenticationService } from '../jwt/_services';

// export const PrivateRoute = ({ component: Component, ...rest }) => (
//   <Route
//     {...rest}
//     render={(props) => {
//       const currentUser = AuthenticationService.currentUserValue;
//       if (!currentUser) {
//         // not logged in so redirect to login page with the return url
//         return (
//           <Redirect
//             to={{
//               pathname: '/authentication/Login',
//               state: { from: props.location },
//             }}
//           />
//         );
//       }

//       return <Component {...props} />;
//     }}
//   />
// );

export function PrivateRoute({ component: Component, ...rest }) {
  // const location = useLocation();
  const location = window.location;

  const currentUser = AuthenticationService.currentUserValue;

  // return user ? <Comp {...props} /> : <Home />;
  return currentUser ? (
    <Route element={<Component {...rest} />} />
  ) : (
    <Navigate
      to='/authentication/Login'
      replace={true}
      state={{ from: location }}
    />
  );
}

export default PrivateRoute;
