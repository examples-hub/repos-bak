import Login from "../views/authentication/Login"

const AuthRoutes = [
  { path: '/authentication/Login', name: 'Login', icon: 'mdi mdi-account-key', component: Login }
];
export default AuthRoutes;
