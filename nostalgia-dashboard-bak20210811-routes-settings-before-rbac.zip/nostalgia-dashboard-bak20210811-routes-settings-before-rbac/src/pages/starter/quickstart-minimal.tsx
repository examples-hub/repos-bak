import * as React from 'react';

type QuickStartPageProps = {
  title?: string;
};

export function QuickStartPage(props: QuickStartPageProps) {
  const { title = 'Quick Start' } = props;
  return (
    <div>
      <h5 className='mb-4'>{title}</h5>
      <p>A quick start page for {title}</p>
    </div>
  );
}

export default QuickStartPage;
