import * as React from 'react';
import { Card, CardBody } from 'reactstrap';

type QuickStartPageProps = {
  title?: string;
  tips?: string;
};

export function QuickStartPage(props: QuickStartPageProps) {
  const { title = 'Quick Start', tips } = props;
  return (
    <div>
      <h5 className='mb-4'>{title}</h5>
      <Card>
        <CardBody>
          {tips ? <h3>{tips}</h3> : <h3>A quick start page for {title}</h3>}
        </CardBody>
      </Card>
    </div>
  );
}

export default QuickStartPage;
