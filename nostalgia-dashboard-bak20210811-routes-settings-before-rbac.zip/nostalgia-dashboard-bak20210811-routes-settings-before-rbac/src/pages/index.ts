import Starter from '../views/starter/starter'

export default Starter;
