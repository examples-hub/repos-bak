import * as React from 'react';

import { QuickStartPage } from '../starter/quickstart';

export function PageNotFound404() {
  return (
    <QuickStartPage
      title='Page Not Found'
      tips='You can try to go back to home page.'
    />
  );
}
export default QuickStartPage;
