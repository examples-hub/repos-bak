import * as React from 'react';
import { Route, Routes, Navigate } from 'react-router-dom';
import AuthRoutes from '../routes/auth-routes';

const Blanklayout = () => {
  return (
    <div className='authentications'>
      <Routes>
        {AuthRoutes.map((prop: any, key) => {
          if (prop.redirect)
            return <Navigate to={prop.pathTo} replace={true} key={key} />;

          return (
            <Route path={prop.path} element={<prop.component />} key={key} />
          );
        })}
      </Routes>
    </div>
  );
};
export default Blanklayout;
