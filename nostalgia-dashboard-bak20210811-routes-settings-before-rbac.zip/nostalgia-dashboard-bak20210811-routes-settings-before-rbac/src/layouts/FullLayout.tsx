import React, { Suspense, useEffect, useState } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';

import routes, { RoutesConfigType } from '../../config/routes';
import Spinner from '../components/spinner';
import { useGlobalContext } from '../store/global-context';
import RoutingPagesErrorBoundary from '../views/exception/RoutingPagesErrorBoundary';
import Customizer from '../views/settings-customizer/Customizer';
import Footer from './footer';
import Header from './header';
import { tryToGetLazyImportedComp } from './maybe-dynamic-components';
import Sidebar from './sidebar';

const FullLayout = (props) => {
  const [width, setWidth] = useState(window.innerWidth);

  const {
    state: { settings },
  } = useGlobalContext();

  useEffect(() => {
    const updateDimensions = () => {
      const element = document.getElementById('main-wrapper');
      setWidth(window.innerWidth);
      switch (settings.activeSidebarType) {
        case 'full':
        case 'iconbar':
          // if (width < 1170) {
          if (width < 940) {
            element.setAttribute('data-sidebartype', 'mini-sidebar');
            element.classList.add('mini-sidebar');
          } else {
            element.setAttribute(
              'data-sidebartype',
              settings.activeSidebarType,
            );
            element.classList.remove('mini-sidebar');
          }
          break;

        case 'overlay':
          // if (width < 767) {
          if (width < 700) {
            element.setAttribute('data-sidebartype', 'mini-sidebar');
          } else {
            element.setAttribute(
              'data-sidebartype',
              settings.activeSidebarType,
            );
          }
          break;

        default:
      }
    };
    if (document.readyState === 'complete') {
      updateDimensions();
    }
    window.addEventListener('load', updateDimensions.bind(null));
    window.addEventListener('resize', updateDimensions.bind(null));
    return () => {
      window.removeEventListener('load', updateDimensions.bind(null));
      window.removeEventListener('resize', updateDimensions.bind(null));
    };
  }, [settings.activeSidebarType, width]);

  return (
    <div
      id='main-wrapper'
      dir={settings.activeDir}
      data-theme={settings.activeTheme}
      data-layout={settings.activeThemeLayout}
      data-sidebartype={settings.activeSidebarType}
      data-sidebar-position={settings.activeSidebarPos}
      data-header-position={settings.activeHeaderPos}
      data-boxed-layout={settings.activeLayout}
    >
      <Header />

      <Sidebar {...props} routes={routes} />

      {/* 基于react-router在不同url展示不同的页面组件 */}
      <div className='page-wrapper d-block'>
        <div className='page-content container-fluid'>
          <RoutingPagesErrorBoundary>
            <Suspense fallback={<Spinner />}>
              <Routes>
                {routes.map((route1: any, key) => {
                  if (
                    route1.navlabel ||
                    route1.path.startsWith('http') ||
                    route1.hideInMenu
                  ) {
                    return null;
                  }

                  if (route1.collapse) {
                    return route1.routes.map((route2: any, key2) => {
                      if (route2.navlabel || route2.path.startsWith('http')) {
                        return null;
                      }

                      if (route2.collapse) {
                        return route2.routes.map((route3: any, key3) => {
                          if (
                            route3.navlabel ||
                            route3.path.startsWith('http')
                          ) {
                            return null;
                          }

                          if (route3.redirect) {
                            return (
                              <Navigate
                                to={route3.pathTo}
                                replace={true}
                                key={key}
                              />
                            );
                          }

                          const MaybeDynamicComp3 =
                            tryToGetLazyImportedComp(route3);

                          // 最长的三级路由
                          return (
                            <Route
                              path={route3.path}
                              // element={<route3.component />}
                              element={<MaybeDynamicComp3 />}
                              key={key3}
                            />
                          );
                        });
                      }

                      if (route2.redirect) {
                        return (
                          <Navigate
                            to={route2.pathTo}
                            replace={true}
                            key={key}
                          />
                        );
                      }

                      const MaybeDynamicComp2 =
                        tryToGetLazyImportedComp(route2);

                      // 二级路由
                      return (
                        <Route
                          path={route2.path}
                          // element={<route2.component />}
                          element={<MaybeDynamicComp2 />}
                          key={key2}
                        />
                      );
                    });
                  }

                  if (route1.redirect) {
                    return (
                      <Navigate to={route1.pathTo} replace={true} key={key} />
                    );
                  }

                  const MaybeDynamicComp1 = tryToGetLazyImportedComp(route1);

                  // 最后处理一级路由
                  return (
                    <Route
                      path={route1.path}
                      // element={<route1.component />}
                      element={<MaybeDynamicComp1 />}
                      key={key}
                    />
                  );
                })}
              </Routes>
            </Suspense>
          </RoutingPagesErrorBoundary>
        </div>
        <Footer />
      </div>

      {/* 右侧浮动配置面板 */}
      <Customizer />
    </div>
  );
};

export default FullLayout;
