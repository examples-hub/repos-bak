import classNames from 'classnames';
import * as React from 'react';
import { useMemo, useState, useCallback } from 'react';
import {
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from 'reactstrap';

import { useGlobalContext } from '../../store/global-context';
import {
  setDir,
  setHeaderPos,
  setLayout,
  setLogoBg,
  setNavbarBg,
  setSidebarBg,
  setSidebarPos,
  setSidebarType,
  setTheme,
} from '../../store/settings/actions';
import { CustomizerItemWithSquareRadio } from './CustomizerItemWithSquareRadio';
import { CustomizerItemWithColorCircle } from './CustomizerItemWithColorCircle';
// import PerfectScrollbar from "react-perfect-scrollbar";

export function Customizer() {
  const {
    state: { settings },
    dispatch,
  } = useGlobalContext();

  const [isSettingsPanelShown, toggleSettingsPanel] = useState<boolean>(false);
  const handleToggleSettingsPanel = useCallback(() => {
    toggleSettingsPanel((prev) => !prev);
  }, []);

  const [isSettingsCogButtonShown, toggleSettingsCogButton] =
    useState<boolean>(true);
  const handleToggleSettingsCogButton = useCallback(() => {
    toggleSettingsCogButton((prev) => !prev);
  }, []);

  const [isQuickSettingsMenuOpen, toggleQuickSettingsMenu] = useState(false);
  const handleToggleQuickSettingsMenu = useCallback(() => {
    toggleQuickSettingsMenu((prev) => !prev);
  }, []);

  const configItemsForLayoutThemes = useMemo(
    () => [
      {
        configTitle: 'Theme Color',
        radioName: 'theme-color',
        items: [
          {
            id: 'theme-light',
            desc: 'Light',
            activeClassName: settings.activeTheme === 'light' ? 'active' : '',
            handleConfig: () => {
              dispatch(setTheme('light'));
              dispatch(setLogoBg('skin6'));
              dispatch(setNavbarBg('skin6'));
              dispatch(setSidebarBg('skin6'));
            },
          },
          {
            id: 'theme-dark',
            desc: 'Dark',
            activeClassName: settings.activeTheme === 'dark' ? 'active' : '',
            handleConfig: () => {
              dispatch(setTheme('dark'));
              dispatch(setLogoBg('skin5'));
              dispatch(setNavbarBg('skin5'));
              dispatch(setSidebarBg('skin5'));
            },
          },
        ],
      },
      {
        configTitle: 'Sidebar Position',
        radioName: 'sidebar-position',
        items: [
          {
            id: 'sidebar-fixed',
            desc: 'Fixed',
            activeClassName:
              settings.activeSidebarPos === 'fixed' ? 'active' : '',
            handleConfig: () => dispatch(setSidebarPos('fixed')),
          },
          {
            id: 'sidebar-absolute',
            desc: 'Not Fixed',
            activeClassName:
              settings.activeSidebarPos === 'absolute' ? 'active' : '',
            handleConfig: () => dispatch(setSidebarPos('absolute')),
          },
        ],
      },

      {
        configTitle: 'Header Position',
        radioName: 'header-position',
        items: [
          {
            id: 'header-fixed',
            desc: 'Fixed',
            activeClassName:
              settings.activeHeaderPos === 'fixed' ? 'active' : '',
            handleConfig: () => dispatch(setHeaderPos('fixed')),
          },
          {
            id: 'header-absolute',
            desc: 'Not Fixed',
            activeClassName:
              settings.activeHeaderPos === 'absolute' ? 'active' : '',
            handleConfig: () => dispatch(setHeaderPos('absolute')),
          },
        ],
      },

      {
        configTitle: 'Layout',
        radioName: 'theme-layout',
        items: [
          {
            id: 'theme-full',
            desc: 'Full',
            activeClassName: settings.activeLayout === 'full' ? 'active' : '',
            handleConfig: () => dispatch(setLayout('full')),
          },
          {
            id: 'theme-boxed',
            desc: 'Boxed',
            activeClassName: settings.activeLayout === 'boxed' ? 'active' : '',
            handleConfig: () => dispatch(setLayout('boxed')),
          },
        ],
      },
      {
        configTitle: 'Direction',
        radioName: 'theme-dir',
        items: [
          {
            id: 'theme-full',
            desc: 'LTR',
            activeClassName: settings.activeDir === 'ltr' ? 'active' : '',
            handleConfig: () => dispatch(setDir('ltr')),
          },
          {
            id: 'theme-rtl',
            desc: 'RTL',
            activeClassName: settings.activeDir === 'rtl' ? 'active' : '',
            handleConfig: () => dispatch(setDir('rtl')),
          },
        ],
      },
      {
        configTitle: 'Sidebar Type',
        radioName: 'theme-sidebar',
        items: [
          {
            id: 'sidebar-full',
            desc: 'Full',
            activeClassName:
              settings.activeSidebarType === 'full' ? 'active' : '',
            handleConfig: () => dispatch(setSidebarType('full')),
          },
          {
            id: 'sidebar-mini',
            desc: 'Mini',
            activeClassName:
              settings.activeSidebarType === 'mini-sidebar' ? 'active' : '',
            handleConfig: () => dispatch(setSidebarType('mini-sidebar')),
          },
          {
            id: 'sidebar-icon',
            desc: 'Icon',
            activeClassName:
              settings.activeSidebarType === 'iconbar' ? 'active' : '',
            handleConfig: () => dispatch(setSidebarType('iconbar')),
          },
          {
            id: 'sidebar-overlay',
            desc: 'Overlay',
            activeClassName:
              settings.activeSidebarType === 'overlay' ? 'active' : '',
            handleConfig: () => dispatch(setSidebarType('overlay')),
          },
        ],
      },
    ],
    [
      dispatch,
      settings.activeDir,
      settings.activeHeaderPos,
      settings.activeLayout,
      settings.activeSidebarPos,
      settings.activeSidebarType,
      settings.activeTheme,
    ],
  );

  const configItemsForColors = useMemo(
    () => [
      {
        configTitle: 'Logo Backgrounds',
        items: [
          {
            bgColor: 'skin1',
            activeClassName: settings.activeLogoBg === 'skin1' ? 'active' : '',
            handleConfig: () => dispatch(setLogoBg('skin1')),
          },
          {
            bgColor: 'skin2',
            activeClassName: settings.activeLogoBg === 'skin2' ? 'active' : '',
            handleConfig: () => dispatch(setLogoBg('skin2')),
          },
          {
            bgColor: 'skin3',
            activeClassName: settings.activeLogoBg === 'skin3' ? 'active' : '',
            handleConfig: () => dispatch(setLogoBg('skin3')),
          },
          {
            bgColor: 'skin4',
            activeClassName: settings.activeLogoBg === 'skin4' ? 'active' : '',
            handleConfig: () => dispatch(setLogoBg('skin4')),
          },
          {
            bgColor: 'skin5',
            activeClassName: settings.activeLogoBg === 'skin5' ? 'active' : '',
            handleConfig: () => dispatch(setLogoBg('skin5')),
          },
          {
            bgColor: 'skin6',
            activeClassName: settings.activeLogoBg === 'skin6' ? 'active' : '',
            handleConfig: () => dispatch(setLogoBg('skin6')),
          },
        ],
      },
      {
        configTitle: 'Navbar Backgrounds',
        items: [
          {
            bgColor: 'skin1',
            activeClassName:
              settings.activeNavbarBg === 'skin1' ? 'active' : '',
            handleConfig: () => dispatch(setNavbarBg('skin1')),
          },
          {
            bgColor: 'skin2',
            activeClassName:
              settings.activeNavbarBg === 'skin2' ? 'active' : '',
            handleConfig: () => dispatch(setNavbarBg('skin2')),
          },
          {
            bgColor: 'skin3',
            activeClassName:
              settings.activeNavbarBg === 'skin3' ? 'active' : '',
            handleConfig: () => dispatch(setNavbarBg('skin3')),
          },
          {
            bgColor: 'skin4',
            activeClassName:
              settings.activeNavbarBg === 'skin4' ? 'active' : '',
            handleConfig: () => dispatch(setNavbarBg('skin4')),
          },
          {
            bgColor: 'skin5',
            activeClassName:
              settings.activeNavbarBg === 'skin5' ? 'active' : '',
            handleConfig: () => dispatch(setNavbarBg('skin5')),
          },
          {
            bgColor: 'skin6',
            activeClassName:
              settings.activeNavbarBg === 'skin6' ? 'active' : '',
            handleConfig: () => dispatch(setNavbarBg('skin6')),
          },
        ],
      },
      {
        configTitle: 'Sidebar Backgrounds',
        items: [
          {
            bgColor: 'skin1',
            activeClassName:
              settings.activeSidebarBg === 'skin1' ? 'active' : '',
            handleConfig: () => dispatch(setSidebarBg('skin1')),
          },
          {
            bgColor: 'skin2',
            activeClassName:
              settings.activeSidebarBg === 'skin2' ? 'active' : '',
            handleConfig: () => dispatch(setSidebarBg('skin2')),
          },
          {
            bgColor: 'skin3',
            activeClassName:
              settings.activeSidebarBg === 'skin3' ? 'active' : '',

            handleConfig: () => dispatch(setSidebarBg('skin3')),
          },
          {
            bgColor: 'skin4',
            activeClassName:
              settings.activeSidebarBg === 'skin4' ? 'active' : '',
            handleConfig: () => dispatch(setSidebarBg('skin4')),
          },
          {
            bgColor: 'skin5',
            activeClassName:
              settings.activeSidebarBg === 'skin5' ? 'active' : '',
            handleConfig: () => dispatch(setSidebarBg('skin5')),
          },
          {
            bgColor: 'skin6',
            activeClassName:
              settings.activeSidebarBg === 'skin6' ? 'active' : '',
            handleConfig: () => dispatch(setSidebarBg('skin6')),
          },
        ],
      },
    ],
    [
      dispatch,
      settings.activeLogoBg,
      settings.activeNavbarBg,
      settings.activeSidebarBg,
    ],
  );

  return (
    <aside
      className={classNames('customizer', {
        'show-service-panel': isSettingsPanelShown,
      })}
      id='customizer'
    >
      {
        // 切换显示或隐藏浮动设置按钮

        isSettingsCogButtonShown && (
          <span
            className='service-panel-toggle text-white'
            onClick={handleToggleSettingsPanel}
          >
            <i className='fa fa-spin fa-cog' />
          </span>
        )
      }
      {/* <PerfectScrollbar> */}
      <div className='customizer-body'>
        <div className='my-3 px-3'>
          <h5 className='fnt-medium m-0'>
            Quick Settings
            <span className='pl-4'>
              <ButtonDropdown
                isOpen={isQuickSettingsMenuOpen}
                toggle={handleToggleQuickSettingsMenu}
              >
                <DropdownToggle caret={false}>
                  <i className='fa fa-cog' />
                </DropdownToggle>
                <DropdownMenu>
                  <DropdownItem onClick={handleToggleSettingsCogButton}>
                    显示 或 隐藏 设置按钮
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>更多设置</DropdownItem>
                </DropdownMenu>
              </ButtonDropdown>
            </span>
            <span
              style={{ cursor: 'pointer' }}
              className='pull-right'
              onClick={handleToggleSettingsPanel}
            >
              <i className='fa fa-close' />
            </span>
          </h5>
        </div>

        {configItemsForLayoutThemes.map((item) => {
          return (
            <CustomizerItemWithSquareRadio key={item.configTitle} {...item} />
          );
        })}

        {configItemsForColors.map((item) => {
          return (
            <CustomizerItemWithColorCircle key={item.configTitle} {...item} />
          );
        })}
      </div>
      {/* </PerfectScrollbar> */}
    </aside>
  );
}

export default Customizer;
