
export { globalInitialState, combiningReducer } from './global-store'
export type { GlobalState } from './global-store'

export { GlobalContext, GlobalProvider, useGlobalContext } from './global-context'
