import * as React from 'react';
import { createContext, useMemo, useReducer, useContext } from 'react';
import { combiningReducer, globalInitialState } from './global-store';

type GlobalContextType = {
  state?: any;
  dispatch?: React.Dispatch<any>;
  version?: string;
};
type GlobalProviderProps = {
  value?: {
    state?: any;
    dispatch?: React.Dispatch<any>;
    version?: string;
  };
  children: JSX.Element;
};

export const GlobalContext = createContext<GlobalContextType | null>(null);

export function GlobalProvider(props: GlobalProviderProps) {
  const { value, children } = props;

  const [state, dispatch] = useReducer(combiningReducer, globalInitialState);

  const ctxVal = useMemo(
    () => ({
      version: `1.0.0`,
      state,
      dispatch,
      ...value,
    }),
    [state, value],
  );

  return (
    <GlobalContext.Provider value={ctxVal}>{children}</GlobalContext.Provider>
  );
}

export const useGlobalContext = () => useContext(GlobalContext);

export default GlobalProvider;
