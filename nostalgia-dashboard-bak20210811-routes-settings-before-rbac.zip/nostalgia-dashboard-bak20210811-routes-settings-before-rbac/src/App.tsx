import './index.scss';
import './assets/scss/style.scss';
import 'fork-awesome/css/fork-awesome.css';

import BlankLayout from './layouts/BlankLayout';
import PageNotFound404 from './pages/exception/404';

import * as React from 'react';
import {
  HashRouter,
  Route,
  BrowserRouter as Router,
  Routes,
} from 'react-router-dom';

import indexRoutes from './routes';
import { GlobalProvider } from './store';

export function App() {
  return (
    <GlobalProvider>
      <Router>
        <Routes>
          <Route path='/authentication/login' element={<BlankLayout />} />

          {indexRoutes.map((prop, key) => {
            return (
              <Route path={prop.path} element={<prop.component />} key={key} />
            );
          })}

          <Route path='*' element={<PageNotFound404 />} />
        </Routes>
      </Router>
    </GlobalProvider>
  );
}

export default App;
