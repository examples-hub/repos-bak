import Starter from '../views/starter/starter';
// ui components
import Alerts from '../views/ui-components/alert';
import Badges from '../views/ui-components/badge';
import Buttons from '../views/ui-components/button';
import Cards from '../views/ui-components/cards';
import LayoutComponent from '../views/ui-components/layout';
import PaginationComponent from '../views/ui-components/pagination';
import PopoverComponent from '../views/ui-components/popover';
import TooltipComponent from '../views/ui-components/tooltip';

// 注意：显示名称过长时，左边就是不对齐的，需要单独处理
const ThemeRoutes = [
  {
    path: 'dashboard',
    name: '主页/工作台/最近动态 Dashboard',
    icon: 'ti-loop',
    component: Starter,
  },
  {
    path: 'badge',
    name: '知识库/文库集合/仓库/批量操作 Badges',
    icon: 'mdi mdi-arrange-send-backward',
    component: Badges,
  },
  {
    path: 'alert',
    name: '文章/笔记/随记 Alerts',
    icon: 'mdi mdi-comment-processing-outline',
    component: Alerts,
  },
  {
    path: 'button',
    name: '知识空间/文件夹集合 Buttons',
    icon: 'mdi mdi-toggle-switch',
    component: Buttons,
  },
  {
    path: 'card',
    name: '收藏/标签 Cards',
    icon: 'mdi mdi-credit-card-multiple',
    component: Cards,
  },
  {
    path: 'grid',
    name: '分享/协作 Grid',
    icon: 'mdi mdi-apps',
    component: LayoutComponent,
  },
  {
    path: 'pagination',
    name: '数据 Pagination',
    icon: 'mdi mdi-priority-high',
    component: PaginationComponent,
  },
  {
    path: 'popover',
    name: '素材/资源/图片/附件/数据 Popover',
    icon: 'mdi mdi-pencil-circle',
    component: PopoverComponent,
  },
  {
    path: 'ui-components/tooltip',
    name: '回收站 Tooltips',
    icon: 'mdi mdi-image-filter-vintage',
    component: TooltipComponent,
  },
  { path: '', pathTo: 'dashboard', name: 'Dashboard', redirect: true },
];
export default ThemeRoutes;
