import './index.css';

import * as React from 'react';

import AppComp from './components/App';

export function App() {
  return <AppComp />;
}

export default App;
