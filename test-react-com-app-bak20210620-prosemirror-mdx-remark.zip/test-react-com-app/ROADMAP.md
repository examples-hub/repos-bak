# roadmap draft

# wontfix

# fix

# new

# refactor

# later

# engineering
- `npm install --legacy-peer-deps` to `npm i` when npm 7 is popular and stable
- jest测试时最好从module字段读取import的包
- package.json的scripts切换到自定义脚本的版本，尽量不直接用.bin下的cli，方便扩展
- Code splitting and asynchronous loading with dynamic `import`
- automate release subpackage workflow
# test
