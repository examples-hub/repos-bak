import './index.css';
import './prosemirror.css';

import { baseKeymap } from 'prosemirror-commands';
import { history, redo, undo } from 'prosemirror-history';
import { keymap } from 'prosemirror-keymap';
import {
  DOMSerializer,
  Fragment,
  Node,
  Schema,
  Slice,
} from 'prosemirror-model';
import {
  EditorState,
  Plugin,
  TextSelection,
  Transaction,
} from 'prosemirror-state';
import { ReplaceStep, Transform } from 'prosemirror-transform';
import { Decoration, DecorationSet, EditorView } from 'prosemirror-view';

const content = document.getElementById('text');
// prosemirror-state 选区/转换系统/状态的数据结构
// prosemirror-view DOM元素/监控行为
// prosemirror-model 数据结构/文档模型

// 任何schema的nodes都必须包含一个顶级元素(默认为doc)和一个text元素
// 注意node的书写顺序，在一些操作后，会根据schema规则补全结构，如果不注意结构，容易死循环(主要是使用group的时候)
const schema = new Schema({
  nodes: {
    doc: {
      // 前面指定可以的node类型, 后面的符号描述个数
      // + 代表一个或者多个, * 代表没有或者有多个, ? 代表没有或者有一个, {n} 代表有n个
      // {n, m} 代表有n - m个, {n, }代表大于等于n个
      // 例如 'paragraph+' 'paragraph{1, 2}'
      // 也可以组合 'heading paragraph*' 代表第一个是个heading，之后可能有paragraph
      // 也可以使用 | 代表着或
      // 在定义时，块节点最好是要求最少有一个子节点，不然浏览器会自动收起这个空节点，使该节点无法编辑(因为输入的是文本节点)
      content: '(paragraph | horizontal_rule)+',
      toDOM() {
        return ['div', 0];
      },
      parseDOM: [{ tag: 'div' }],
    },
    paragraph: {
      content: 'inline*',
      // _ 为代表允许所有的marks, 空字符串代表不允许任何marks
      // 指定多个marks使用空格分开
      marks: '_',
      // 使用toDOM指定node的渲染方式
      // 该字段为一个函数，返回一个DOM对象或者一个数组描述它
      // [标签名, 标签属性, 是否有内容]
      // [标签名, 是否有内容]
      // 如果有内容填0，没有则不填
      toDOM() {
        return ['p', 0];
      },
      parseDOM: [{ tag: 'p' }],
    },
    horizontal_rule: {
      toDOM() {
        return ['hr'];
      },
      parseDOM: [{ tag: 'hr' }],
    },
    image: {
      // 可以使用group将多个node进行归类，在content使用
      group: 'inline',
      // node可以设置attrs来存储一些信息
      attrs: {
        // 可以使用default设置默认值
        alt: { default: null },
        // 如果不设置default，在创建时不提供该attr会报错
        // 而且也没法自动生成满足schema约束的node
        src: {},
      },
      // 规定node可否被进入
      selectable: false,
      inline: true,
      // 这个toDOM默认会传递一个node参数
      toDOM(node) {
        const { src, alt } = node.attrs;

        return ['img', { src, alt }];
      },
      parseDOM: [
        {
          tag: 'img[src]',
          getAttrs(dom) {
            return {
              src: dom.getAttribute('src'),
              alt: dom.getAttribute('alt'),
            };
          },
        },
      ],
    },
    text: {
      group: 'inline',
      // text的inline默认为true, 可以不写
      inline: true,
    },
  },
  // 默认情况下，marks允许使用在所有的inline content上
  // 但是你可以通过配置node的marks字段来将它应用到node上
  marks: {
    strong: {
      toDOM() {
        return ['strong'];
      },
      parseDOM: [
        { tag: 'strong' },
        // getAttrs用来验证是否匹配可以使用该mark条件，
        // 也可以用来获取该node或者mark必要的一些属性，详情可以看node的image和mark的highlight
        {
          tag: 'b',
          getAttrs: (dom) => dom.style.fontWeight != 'normal' && null,
        },
        {
          style: 'font-weight',
          getAttrs: (value) => /^(bold(er)?|[5-9]\d{2,})$/.test(value) && null,
        },
      ],
    },
    em: {
      // 因为mark需要始终需要修饰内容，所以是否有内容的位置不需要特别指定0，默认值就是0
      toDOM() {
        return ['em'];
      },
      parseDOM: [{ tag: 'em' }, { tag: 'i' }, { style: 'font-style=italic' }],
    },
    highlight: {
      attrs: {
        color: { default: '' },
      },
      // mark的toDOM提供的是该mark的对象
      toDOM(mark) {
        const { color } = mark.attrs;

        // style只能是字符串，无法用对象方法来写{ color }
        return ['span', { style: `color: ${color}` }];
      },
      parseDOM: [
        {
          tag: 'span[style]', // 可以使用CSS选择器
          // 使用getAttrs获取属性值，参数为DOM对象
          getAttrs(dom) {
            return { color: dom.style.color };
          },
        },
      ],
    },
  },
});

// 1. doc结构类似DOM, 但是与DOM不同的是inline的存储
//    doc并不会像DOM一样无限嵌套, 而是将相似的节点进行分割或者合并
//    形成一个平面序列，将markup做完metadata附加到inline上
//    这种结构可以使用offset进行定位，也方便进行分割或修改样式操作
// 3. doc不允许出现空的text节点
// DOMParser可以根据提供的schema解析DOM来创建doc，前提是schema提供parseDOM
// <div id="text"><p>This is <strong>strong text with <em>emphasis</em></strong></p></div>
// import { DOMParser } from 'prosemirror-model'
// const doc = DOMParser.fromSchema(schema).parse(content);
// 也可以通过schema来创建(https://prosemirror.net/docs/ref/#model.Schema.node)
let doc = schema.node('doc', null, [
  schema.node('paragraph', null, [
    schema.text('This is '),
    // 可以向text中添加mark
    schema.text('strong text with ', [schema.mark('strong')]),
    // mark可以是多个
    schema.text('emphasis', [
      schema.mark('strong'),
      schema.mark('em'),
      schema.mark('highlight', { color: 'red' }),
    ]),
  ]),
  schema.node('paragraph', null, [
    schema.text('strong text with ', [schema.mark('strong')]),
    schema.node('image', { src: 'https://ccn.dev.beacontech.io/logo.png' }),
  ]),
]);

// 可以使用toJSON和nodeFromJson正反序列化
const json = doc.toJSON();
const nodeFromJSON = schema.nodeFromJSON(json);

console.log(
  ';;schemaJson, ',
  JSON.stringify(json) === JSON.stringify(nodeFromJSON.toJSON()),
); // true

// 格式化DOM

console.log(
  '格式化dom, ',
  DOMSerializer.fromSchema(schema).serializeNode(doc).innerHTML,
);

// 可以使用NodeType的createChecked或者Node的check方法检查结构是否正确
// schema.nodes.doc.createChecked(null, [schema.text('text')]) // 会报错
// 不会报错
console.log(
  ';;checkSchema, ',
  schema.node('doc', null, [schema.node('paragraph')]).check(),
);

// 整个doc有一个顶级节点，顶级节点包含一些块节点，块节点包含一些文本节点，文本块节点包含一些行内节点
// 也有可能是顶级节点是一个本文块节点，但是它的子节点只能是行内节点
const docTextBlock = schema.node('paragraph', null, [
  schema.text('This is '),
  // 可以向text中添加mark
  schema.text('strong text with ', [schema.mark('strong')]),
  // mark可以是多个
  schema.text('emphasis', [schema.mark('strong'), schema.mark('em')]),
]);
// doc的嵌套结构规则由schema决定
// const docError = schema.node('paragraph', null, [schema.node('paragraph')]) 会报错

// index 有两种
// 1. 使用offset检索树结构
// 2. 使用token计数单位检索扁平结构

// offset可以像DOM一样使用，主要方法是childCount和一些child的method
docTextBlock.forEach((item) => {
  typeof item.textContent === 'string'; // 每个node中的文本
  // typeof item.marks === 'array'; // 改节点应用的marks, 不能是array
});

docTextBlock.textContent === 'This is strong text with emphasis';
docTextBlock.hasMarkup(schema.nodes.paragraph) === true;
// 也可以使用descendants递归遍历
docTextBlock.descendants((node, pos, parent) => {
  node instanceof Node;
  typeof pos === 'number'; // token计数
  parent === docTextBlock;
});

// 也可以使用nodesBetween指定位置，但是第一二参数是token计数，同样也会递归
doc.nodesBetween(0, 30, (node, pos, parent, index) => {
  node instanceof Node;
  typeof pos === 'number'; // token计数
  parent === doc; // 不一定相等
  // index; // 跟数组遍历的index一样 0 1 2 3 4
});

// token的计算规则，用来需要指定位置
// 1. doc开始位置为0
// 2. 进入/离开一个node记1(也就是标签<p>, </p>)
// 3. 一个文本文字记1
// 4. 一个空叶节点记1
// 可以使用nodeSize访问节点数
docTextBlock.nodeSize === docTextBlock.content.size - 2; // docTextBlock带一个doc的开关标签，所以比content.size大2

// Node.resolve 可以查一些结构位置信息
docTextBlock.resolve(1); // TODO: 没研究懂...

// openStart代表着在开头补了多少个标签，openEnd是结尾
// slice导出的openStart, openEnd的深度是根据该fragment计算的，而不是doc
doc.slice(3, 4); // [0, 0]
doc.slice(1, doc.content.size); // [1, 0]
doc.slice(0, 3); // [0, 1]

// 不应该直接修改doc，而是通过node或者fragment上的一些方法去生成一个新的doc
const slice = doc.slice(26, 34);
doc = doc.replace(1, 9, slice);

// node有一些更新的方法
schema.node('paragraph').replace(0, 0, slice);
// fragment也有一些更新doc的方法
slice.content.append(slice.content);

// isBlock 块节点
schema.node('paragraph').isBlock === true;
// isText 文本节点
schema.text('This is').isText === true;
// isInline 行内节点
schema.text('This is').isInline === true;
// isLeaf 叶节点
schema.node('image', { src: 'https://ccn.dev.beacontech.io/logo.png' })
  .isLeaf === true;
// inlineContent 是否允许行内元素添加
schema.node('horizontal_rule').inlineContent === false;
// isTextblock 文字块节点 (例如：段落)
schema.node('paragraph').isTextblock === true;

// node的content是fragment实例, 他是一个node数组
schema.node('paragraph', null, [schema.text('test')]).content instanceof
  Fragment ===
  true;
// 没有内容或者不允许有内容的空叶节点(empty leaf node)它们都是共享一个Fragment.empty
schema.node('image', { src: 'https://ccn.dev.beacontech.io/logo.png' })
  .content === Fragment.empty;
schema.node('paragraph').content === Fragment.empty;
schema.node('image', { src: 'https://ccn.dev.beacontech.io/logo.png' })
  .content === schema.node('paragraph').content;

// 创建一个fragment
const fragment = Fragment.from(schema.text('fragment'));
// 创建一个slice
// TODO: 对于Slice的深度问题还没研究明白 https://prosemirror.net/docs/guide/#doc
const sliceOfFragment = new Slice(fragment, 0, 0);
// 创建一个step
const step = new ReplaceStep(4, 6, sliceOfFragment);
// 通过getMap获取到map可以拿到转变之后的位置信息
const map = step.getMap();
map.map(8) === 11; // 向后移动，因为添加了新的字段
map.map(2) === 2; // 不变，因为替换发生在之后的位置
// apply有可能会失败
// 如果有错误，那么doc为null，failed有错误信息
const resultOfStep = step.apply(doc);

// 可以使用transform应用一系列step
const transform = new Transform(resultOfStep.doc);
// 大多数transform方法都返回this本身，可以链式调用
transform
  .addMark(1, 9, schema.mark('strong'))
  .addMark(1, 9, schema.mark('highlight', { color: 'red' }));
// TODO: 关于Node的一些操作没搞懂， https://prosemirror.net/docs/guide/#transform
transform.split(10).delete(2, 5);
// 与step的getMap类似，mapping也可以拿到转变之后的位置信息
transform.mapping.map(15) === 14;
transform.mapping.map(6) === 3;
transform.mapping.map(10) === 9; // 位置10正好是分割处，这时向前或者向后移动都OK，但默认是向后移动
transform.mapping.map(10, -1) === 7; // 可以通过第二个参数，调整为向前移动

const ownPlugin = new Plugin({
  // plugin可以添加一些EditorProps https://prosemirror.net/docs/ref/#view.EditorProps
  // 除了editor的state和dispatchTransaction
  props: {
    handleKeyDown(view, event) {
      event instanceof Event; // DOM事件
      view instanceof EditorView; // 此处操作前的view
      return false; // 如果是true那么prosemirror就不会处理该事件
    },
  },
  // 也可以定义自己的状态
  state: {
    init() {
      return 0;
    },
    // 当发生transaction时会触发，其实也相当于state发生修改
    apply(tr, value) {
      tr instanceof Transaction;
      if (tr.getMeta(ownPlugin)) return value; // getMeta获取的mate可以使用tr.setMeta(ownPlugin, true) 来设置
      return value + 1; // 应该返回一个新的值，特别是引用数据类型
    },
  },
});

const state = EditorState.create({
  schema,
  doc: transform.doc,
  // 插件定义在state中，因为他们需要访问state
  plugins: [
    history(),
    // undo redo baseKeymap这种都是commands, commands可以绑定到键盘，也可以暴露给用户使用
    keymap({ 'Mod-z': undo, 'Mod-y': redo }),
    keymap(baseKeymap),
    ownPlugin,
  ],
});

ownPlugin.getState(state) === 0; // 可以使用getState获取当前editor state中plugin的state

// state 保存着选区，当前激活的marks，文档内容
state.doc;
state.selection; // 选区默认从第一个块节点开始 from为1
state.storedMarks;

// selection 每次操作会生成一个新的selection
state.selection.from; // 选区的开始位置
state.selection.to; // 选区的结束位置
state.selection.anchor; // 选区的固定侧，最开始点击的位置
state.selection.head; // 选区的移动侧，最后鼠标截止的位置
// selection最常见的两个子类是TextSelection，NodeSelection

// transaction是transform的子类，另外还包含一些高阶方法 https://prosemirror.net/docs/ref/#state.Transaction
const stateOfTransaction = state.apply(
  state.tr
    .setSelection(TextSelection.create(state.doc, 8))
    .setStoredMarks([schema.mark('strong')])
    .insertText('transaction insert text') // transaction方法
    .delete(1, 3), // transfrom方法
);

class ImageView {
  constructor(node, view, getPos) {
    // editor将使用dom作为节点的显示
    this.dom = document.createElement('img');
    this.dom.src = node.attrs.src;
    this.dom.alt = node.attrs.alt;
    this.dom.addEventListener('click', (e) => {
      e.preventDefault();
      const alt = window.prompt('Image alt text:');
      if (alt)
        view.dispatch(
          // dispatch触发dispatchTransaction, apply transaction, updateState view
          // 使用getPos可以获取到当前node的位置
          view.state.tr.setNodeMarkup(getPos(), null, {
            alt,
            src: node.attrs.src,
          }),
        );
    });
  }
  stopEvent() {
    return true; // true表示prosemirror是否忽略(最直观的反应是，点击图片prosemirror的dispatchTransaction是否会相应)
  }
}

class ParagraphView {
  constructor(node) {
    // 如果提供contentDOM的话。prosemirror会把该节点内容渲染到contentDOM里面
    // 如果不提供的话，该节点渲染完全取决于你
    this.dom = this.contentDOM = document.createElement('p');
    if (node.content.size === 0) this.dom.style.background = 'yellow';
  }

  // update 返回true代表更新成功
  update(node) {
    if (node.type.name !== 'paragraph') return false;
    this.dom.style.background = node.content.size === 0 ? 'yellow' : '';
    return true;
  }
}

const view = new EditorView(content, {
  state: stateOfTransaction,
  decorations(state) {
    return DecorationSet.create(state.doc, [
      // Decoration from to 需要精确指定到node的起始和结束位置
      // from 一般是上一个node的结尾， to 可以使用当前node的nodeSize + from
      Decoration.node(31, 63, { style: 'background: blue' }),
      Decoration.inline(31, 63, { style: 'color: red' }),
      Decoration.widget(4, () => {
        const span = document.createElement('span');

        span.style.background = 'yellow';
        span.style.position = 'absolute';
        span.style.top = '1px';
        span.innerText = 'widget';
        return span;
      }),
    ]);
  },
  nodeViews: {
    image(node, view, getPos) {
      return new ImageView(node, view, getPos);
    },
    paragraph(node) {
      return new ParagraphView(node);
    },
  },
});

// command
function deleteSelection(state, dispatch) {
  if (state.selection.empty) return false;
  if (dispatch) dispatch(state.tr.deleteSelection()); // 为了查询该操作在state是否可以执行做出的判断
  return true;
}

// command 还可以指定第三个参数view
function blinkView(_state, dispatch, view) {
  if (dispatch) {
    view.dom.style.background = 'yellow';
    setTimeout(() => (view.dom.style.background = ''), 1000);
  }
  return true;
}

// 可以使用chainCommands将多个command绑定到一起，然后一个一个执行，直到第一个返回true
// 如果都不返回，那么执行浏览器默认行为

// editor state优先级
// editor直接定义的state > plugins的调用顺序
// editor attributes和decorations会合并处理

// 可以使用setProps设置除state以外的props
view.setProps({
  // 任何修改都会生成一个transaction
  dispatchTransaction(tr) {
    // 应用transaction生成一个新的state
    const state = view.state.apply(tr);

    // 可以在dispatchTransaction中拦截transaction操作
    if (state.doc.textContent.length > 100) return;
    // 通过updateState更新view
    view.updateState(state);
  },
});

// 数据流
// EditorView展示数据 -> 触发DOM Event -> 生成Transaction -> 生成新的EditorState -> 更新EditorView
