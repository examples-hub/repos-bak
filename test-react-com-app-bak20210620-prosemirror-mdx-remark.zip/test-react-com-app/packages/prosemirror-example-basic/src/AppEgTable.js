import './index.css';
import './prosemirror.css';
import './prosemirror-tables.css';

import { baseKeymap } from 'prosemirror-commands';
import { buildMenuItems, exampleSetup } from 'prosemirror-example-setup';
import { keymap } from 'prosemirror-keymap';
import { Dropdown, MenuItem } from 'prosemirror-menu';
import { DOMParser as PDOMParser, Schema } from 'prosemirror-model';
import { schema as baseSchema } from 'prosemirror-schema-basic';
import { EditorState } from 'prosemirror-state';
import {
  addColumnAfter,
  addColumnBefore,
  addRowAfter,
  addRowBefore,
  deleteColumn,
  deleteRow,
  deleteTable,
  goToNextCell,
  mergeCells,
  setCellAttr,
  splitCell,
  toggleHeaderCell,
  toggleHeaderColumn,
  toggleHeaderRow,
} from 'prosemirror-tables';
import {
  columnResizing,
  fixTables,
  tableEditing,
  tableNodes,
} from 'prosemirror-tables';
import { EditorView } from 'prosemirror-view';

let schema = new Schema({
  nodes: baseSchema.spec.nodes.append(
    tableNodes({
      tableGroup: 'block',
      cellContent: 'block+',
      cellAttributes: {
        background: {
          default: null,
          getFromDOM(dom) {
            return (dom.style && dom.style.backgroundColor) || null;
          },
          setDOMAttr(value, attrs) {
            if (value)
              attrs.style = (attrs.style || '') + `background-color: ${value};`;
          },
        },
      },
    }),
  ),
  marks: baseSchema.spec.marks,
});

let menu = buildMenuItems(schema).fullMenu;
function item(label, cmd) {
  return new MenuItem({ label, select: cmd, run: cmd });
}
let tableMenu = [
  item('Insert column before', addColumnBefore),
  item('Insert column after', addColumnAfter),
  item('Delete column', deleteColumn),
  item('Insert row before', addRowBefore),
  item('Insert row after', addRowAfter),
  item('Delete row', deleteRow),
  item('Delete table', deleteTable),
  item('Merge cells', mergeCells),
  item('Split cell', splitCell),
  item('Toggle header column', toggleHeaderColumn),
  item('Toggle header row', toggleHeaderRow),
  item('Toggle header cells', toggleHeaderCell),
  item('Make cell green', setCellAttr('background', '#dfd')),
  item('Make cell not-green', setCellAttr('background', null)),
];

menu.splice(2, 0, [new Dropdown(tableMenu, { label: 'Table' })]);
const parser = new DOMParser();

// let doc = DOMParser.fromSchema(schema).parse(document.querySelector("#content"))

let doc = PDOMParser.fromSchema(schema).parse(
  parser.parseFromString(
    `<table>
  <tr><th colspan="3" data-colwidth="100,0,0">Wide header</th></tr>
  <tr><td>One</td><td>Two</td><td>Three</td></tr>
  <tr><td>Four</td><td>Five</td><td>Six</td><td>seven</td></tr>
</table>`,
    'text/xml',
  ).documentElement,
);

let state = EditorState.create({
  doc,
  plugins: [
    columnResizing(),
    tableEditing(),
    keymap({
      Tab: goToNextCell(1),
      'Shift-Tab': goToNextCell(-1),
    }),
  ].concat(exampleSetup({ schema, menuContent: menu })),
});

let fix = fixTables(state);
if (fix) state = state.apply(fix.setMeta('addToHistory', false));

// document.execCommand('enableObjectResizing', false, false);
// document.execCommand('enableInlineTableEditing', false, false);

if (!document.querySelector('#editor')) {
  const editor = document.createElement('div');
  editor.id = 'editor';
  document.querySelector('body').appendChild(editor);
}

const view = new EditorView(document.querySelector('#editor'), {
  state,
  dispatchTransaction(transaction) {
    console.log(
      'Document size went from',
      transaction.before.content.size,
      'to',
      transaction.doc.content.size,
    );
    let newState = view.state.apply(transaction);
    console.log(';;newState, ', newState);

    // state更新一定会执行updateState()方法，但通常被封装进了其他方法
    view.updateState(newState);
  },
});
