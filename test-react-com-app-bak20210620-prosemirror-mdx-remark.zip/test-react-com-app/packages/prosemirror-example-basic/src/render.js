// import './App';
// import './AppEgMinimal';
// import './AppEgTable';
import './AppEgStarterWebpackBreakout';
// import './AppProseMirrorTest';

// if (module.hot) {
//   module.hot.accept('./App.js', () => {
//     import('./App');
//   });
// }
