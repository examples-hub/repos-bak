import './index.css';
import './prosemirror.css';

import { baseKeymap } from 'prosemirror-commands';
import { history, redo, undo } from 'prosemirror-history';
import { keymap } from 'prosemirror-keymap';
import { DOMParser, DOMSerializer, Schema } from 'prosemirror-model';
import { schema } from 'prosemirror-schema-basic';
import { addListNodes } from 'prosemirror-schema-list';
import { EditorState, TextSelection } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';

let state = EditorState.create({
  schema,
  plugins: [
    history(),
    // 处理 undo、redo
    keymap({ 'Mod-z': undo, 'Mod-y': redo, 'Mod-Shift-z': redo }),
    // 处理常用编辑命令，如enter换行
    keymap(baseKeymap),
  ],
});
let view = new EditorView(document.querySelector('#editor'), {
  state,

  dispatchTransaction(transaction) {
    console.log(
      'Document size went from',
      transaction.before.content.size,
      'to',
      transaction.doc.content.size,
    );
    let newState = view.state.apply(transaction);
    console.log(';;newState, ', newState);

    // state更新一定会执行updateState()方法，但通常被封装进了其他方法
    view.updateState(newState);
  },
});
