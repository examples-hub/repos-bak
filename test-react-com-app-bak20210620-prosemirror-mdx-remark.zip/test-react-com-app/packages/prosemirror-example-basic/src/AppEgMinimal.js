import './index.css';
import './prosemirror.css';

import { schema } from 'prosemirror-schema-basic';
import { EditorState } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';

// ------------- minimal prosemirror editor ------------- //
// 注意默认编辑器没有边框但可闪烁光标进行编辑，需要自己调整样式进行观察
// 按enter键不会换行，因为默认只配置了setState更新状态，没有任何其他配置

let state = EditorState.create({ schema });
// let view = new EditorView(document.getElementById('root'), { state });

let view = new EditorView(document.querySelector('#editor'), {
  state,

  dispatchTransaction(transaction) {
    console.log(
      'Document size went from',
      transaction.before.content.size,
      'to',
      transaction.doc.content.size,
    );
    let newState = view.state.apply(transaction);
    console.log(';;newState, ', newState);

    // state更新一定会执行updateState()方法，但通常被封装进了其他方法
    view.updateState(newState);
  },
});
