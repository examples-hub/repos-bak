import React from 'react';
import ReactDOM from 'react-dom';
// import log from 'package-a';
import App from './App';

// import './index.css';

// log();

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root'),
);
