module.exports = {
  color: {
    red: {
      v100: {
        value: '#db3236',
      },
    },
    green: {
      v100: {
        value: '#3cba54',
      },
    },
    blue: {
      v100: {
        value: '#4885ed',
      },
    },
    yellow: {
      v100: {
        value: '#f4c20d',
      },
    },
  },
};
