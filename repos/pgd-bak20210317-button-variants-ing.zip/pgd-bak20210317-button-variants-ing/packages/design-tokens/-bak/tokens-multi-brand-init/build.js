// import StyleDictionary from 'style-dictionary';
const StyleDictionary = require('style-dictionary');

StyleDictionary.registerFormat({
  name: 'css/variables',
  formatter: function ({ dictionary, options }) {
    return `${this.selectorName} {
      ${dictionary.allProperties
        .map((prop) => {
          // let value = JSON.stringify(prop.value);
          let value = prop.value;
          // console.log('==, ', JSON.stringify(options));

          if (options.outputReferences) {
            if (dictionary.usesReference(prop.original.value)) {
              const reference = dictionary.getReference(prop.original.value);
              // console.log('==, ', JSON.stringify(reference));
              value = reference.name;
              return `  --${prop.name}: var(--${value}, ${prop.value});`;
            }
          }
          return `  --${prop.name}: ${prop.value};`;
        })
        .join('\n')}
    }`;
  },
});

function getSDConfig(themeName) {
  return {
    // 指定source时，tokens文件的声明顺序不重要，可以去掉component文件夹
    // include: ['tokens/global/**/*.js', `tokens/theme/pg/**/*.js`],
    include: ['tokens/global/**/*.js', `tokens/theme/pg/*.js`],
    source: [`tokens/theme/${themeName}/**/*.js`],
    platforms: {
      // scss: {
      //   transformGroup: 'scss',
      //   buildPath: `build/${themeName}/`,
      //   files: [
      //     {
      //       destination: 'variables.scss',
      //       format: 'scss/variables',
      //     },
      //   ],
      // },
      css: {
        transformGroup: 'css',
        buildPath: `dist/`,
        files: [
          {
            destination: `${themeName}.css`,
            format: 'css/variables',
            selectorName: `.${themeName}`,
            options: {
              outputReferences: true,
            },
          },
        ],
      },
      // ...
    },
  };
}

function startBuildMultiThemes() {
  const themeNameArr = ['halfmoon', 'spectrum', 'pg'];
  themeNameArr.forEach((themeName) => {
    console.log('\n==============================================');
    console.log(`\nprocessing:  [${themeName}]`);
    const SD = StyleDictionary.extend(getSDConfig(themeName));
    SD.buildAllPlatforms();
    console.log('\nend processing');
  });
}
console.log('build started');

startBuildMultiThemes();
console.log('\n==============================================');
console.log('\nbuild completed!');
