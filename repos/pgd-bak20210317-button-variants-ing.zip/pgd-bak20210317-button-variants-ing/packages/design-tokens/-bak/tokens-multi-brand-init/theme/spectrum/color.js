module.exports = {
  color: {
    theme: {
      primary: { value: '#3cba54' },
      secondary: { value: '#4885ed' },
    },
  },
};
