module.exports = {
  color: {
    theme: {
      primary: { value: '#db3236' },
      secondary: { value: '#fcc20d' },
    },
  },
};
