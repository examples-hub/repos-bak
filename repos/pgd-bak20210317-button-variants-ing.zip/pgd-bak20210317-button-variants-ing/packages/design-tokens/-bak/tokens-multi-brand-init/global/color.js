module.exports = {
  color: {
    base: {
      black: { value: '#000000' },
      gray: {
        light: { value: '#CCCCCC' },
        medium: { value: '#999999' },
        dark: { value: '#111111' },
      },
      white: { value: '#FFFFFF' },
    },
    primary: { value: '{color.theme.primary.value}' },
    secondary: { value: '{color.theme.secondary.value}' },
    action: {
      primary: { value: '{color.primary.value}' },
      secondary: { value: '{color.secondary.value}' },
      tertiary: { value: '{color.base.gray.medium.value}' },
    },
  },
};
