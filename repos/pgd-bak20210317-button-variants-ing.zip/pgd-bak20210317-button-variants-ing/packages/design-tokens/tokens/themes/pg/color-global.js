const { globalPrefix: prefix4g } = require('../../utils/globalConfig');
module.exports = {
  brand: {
    // primary: { value: '#3cba54' },
    // primary: { value: '#789262' },
    // primary: { value: '#21a675' },
    // secondary: { value: '#' },
  },
  semantic: {
    // success: { value: `` },
    // info: { value: `` },
    // warning: { value: `` },
    // danger: { value: `` },
  },
};
