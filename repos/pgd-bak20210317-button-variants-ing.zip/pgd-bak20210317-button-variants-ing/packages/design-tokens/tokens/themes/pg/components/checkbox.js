module.exports = {
  color: { value: '#3cba54' },
};
