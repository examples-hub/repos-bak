module.exports = {
  base: {
    border: {
      width: { value: '1px' },
      radius: { value: '0.4rem' },
    },
  },
};
