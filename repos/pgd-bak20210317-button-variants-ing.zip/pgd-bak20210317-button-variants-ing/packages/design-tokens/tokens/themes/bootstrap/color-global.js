const { globalPrefix: prefix4g } = require('../../utils/globalConfig');
module.exports = {
  brand: {
    primary: { value: '#0d6efd' },
    // secondary: { value: '#' },
  },
  semantic: {
    success: { value: `` },
    info: { value: `` },
    warning: { value: `` },
    danger: { value: `` },
  },
};
