module.exports = {
  globalPrefix: 'pg-g',
  compPrefix: 'pg-c',
};
