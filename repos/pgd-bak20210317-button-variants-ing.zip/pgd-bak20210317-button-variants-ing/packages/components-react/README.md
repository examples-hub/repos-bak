# @pgd/components-react

- the react implementation of the prospect garden design system

# overview

- features
  - themeable react components for the web

# usage
