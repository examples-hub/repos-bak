# ckeditor5-build-classic
> Create my own CKEditor 5 build with customized plugins, toolbar and language.

## installation
```shell
npm i @jswork/ckeditor5-build-classic
```

## online-builder
- https://ckeditor.com/ckeditor-5/online-builder/