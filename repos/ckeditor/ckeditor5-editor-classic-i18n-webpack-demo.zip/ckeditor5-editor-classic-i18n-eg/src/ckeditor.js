/**
 * @license Copyright (c) 2014-2021, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

import Bold from '@ckeditor/ckeditor5-basic-styles/src/bold.js';
import Italic from '@ckeditor/ckeditor5-basic-styles/src/italic.js';
import ClassicEditor from '@ckeditor/ckeditor5-editor-classic/src/classiceditor.js';
import Essentials from '@ckeditor/ckeditor5-essentials/src/essentials.js';
import Heading from '@ckeditor/ckeditor5-heading/src/heading.js';
import Image from '@ckeditor/ckeditor5-image/src/image.js';
import ImageCaption from '@ckeditor/ckeditor5-image/src/imagecaption.js';
import ImageResize from '@ckeditor/ckeditor5-image/src/imageresize.js';
import ImageStyle from '@ckeditor/ckeditor5-image/src/imagestyle.js';
import ImageToolbar from '@ckeditor/ckeditor5-image/src/imagetoolbar.js';
import ImageUpload from '@ckeditor/ckeditor5-image/src/imageupload.js';
import Paragraph from '@ckeditor/ckeditor5-paragraph/src/paragraph.js';

// import { Card } from '@toe/ckeditor5-playgrounds';
// import { Card } from 'ckeditor5-playgrounds';
import { Card } from 'ckeditor-playgrounds';

class Editor extends ClassicEditor {}

// Plugins to include in the build.
Editor.builtinPlugins = [
  // Autoformat,
  // AutoLink,
  // BlockQuote,
  Bold,
  // Code,
  // CodeBlock,
  Essentials,
  // FontBackgroundColor,
  // FontColor,
  // FontSize,
  // GeneralHtmlSupport,
  Heading,
  // HorizontalLine,
  // HtmlComment,
  // HtmlEmbed,
  Image,
  ImageCaption,
  ImageResize,
  ImageStyle,
  ImageToolbar,
  ImageUpload,
  // Indent,
  // IndentBlock,
  Italic,
  // Link,
  // LinkImage,
  // List,
  // ListStyle,
  // MediaEmbed,
  // PageBreak,
  Paragraph,
  // PasteFromOffice,
  // RemoveFormat,
  // SourceEditing,
  // SpecialCharacters,
  // SpecialCharactersArrows,
  // SpecialCharactersCurrency,
  // SpecialCharactersEssentials,
  // SpecialCharactersLatin,
  // SpecialCharactersMathematical,
  // SpecialCharactersText,
  // StandardEditingMode,
  // Strikethrough,
  // Subscript,
  // Superscript,
  // Table,
  // TableCaption,
  // TableCellProperties,
  // TableProperties,
  // TableToolbar,
  // TextTransformation,
  // Underline,
  // WordCount,
  Card,
];

// Editor configuration.
Editor.defaultConfig = {
  toolbar: {
    items: [
      'heading',
      '|',
      'bold',
      'italic',
      // "link",
      // "bulletedList",
      // "numberedList",
      // "|",
      // "outdent",
      // "indent",
      // "|",
      'imageUpload',
      // "blockQuote",
      // "insertTable",
      // "mediaEmbed",
      // "undo",
      // "redo",
      // "codeBlock",
      // "htmlEmbed",
      // "sourceEditing",
      // "specialCharacters",
      // "superscript",
      // "subscript",
      // "fontBackgroundColor",
      // "fontColor",
      // "fontSize",
      // "code",
      // "removeFormat",
      // "strikethrough",
      // "todoList",
      // "underline",
      'cardToolbarItem',
    ],
  },
  language: 'zh-cn',
  image: {
    toolbar: [
      'imageTextAlternative',
      'imageStyle:inline',
      'imageStyle:block',
      'imageStyle:side',
    ],
  },
  // table: {
  //   contentToolbar: [
  //     "tableColumn",
  //     "tableRow",
  //     "mergeTableCells",
  //     "tableCellProperties",
  //     "tableProperties",
  //   ],
  // },
};

export default Editor;
