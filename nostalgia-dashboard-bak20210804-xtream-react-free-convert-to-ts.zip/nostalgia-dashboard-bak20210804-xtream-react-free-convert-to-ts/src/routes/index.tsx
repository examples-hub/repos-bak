import Fulllayout from '../layouts/fulllayout';

const indexRoutes = [{ path: '/*', name: 'Starter', component: Fulllayout }];

export default indexRoutes;
