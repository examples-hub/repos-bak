import * as React from 'react';
import {
  Button,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Nav,
  NavItem,
  Navbar,
  NavbarBrand,
  UncontrolledDropdown,
} from 'reactstrap';

import logodarkicon from '../../../assets/images/logo-icon.png';
import logolighticon from '../../../assets/images/logo-light-icon.png';
import logolighttext from '../../../assets/images/logo-light-text.png';
import logodarktext from '../../../assets/images/logo-text.png';
import profilephoto from '../../../assets/images/users/1.jpg';

const Header = () => {
  const showMobilemenu = () => {
    document.getElementById('main-wrapper').classList.toggle('show-sidebar');
  };

  return (
    <header className='topbar navbarbg' data-navbarbg='skin1'>
      <Navbar className='top-navbar' dark expand='md'>
        {/* <div className="navbar-header" id="logobg" data-logobg="skin6"> */}
        <div
          className='navbar-header'
          id='logobg'
          data-logobg='skin6'
          style={{ backgroundColor: 'silver' }}
        >
          <NavbarBrand href='/'>
            {/* 这里放一个漂浮的按钮，用来折叠侧边栏，漂浮按钮放左边或右边可设置 */}
            <b className='logo-icon'>
              {/* <img src={logodarkicon} alt='homepage' className='dark-logo' /> */}
              {/* <img src={logolighticon} alt='homepage' className='light-logo' /> */}
              三
            </b>
            <span className='logo-text'>
              {/* <img src={logodarktext} alt='homepage' className='dark-logo' /> */}
              {/* <img src={logolighttext} className='light-logo' alt='homepage' /> */}
              xtreme logo is IN Header,NOT in sidebar
            </span>
          </NavbarBrand>
          {/* Mobile View Toggler: visible only if viewport width < 768px */}
          <button
            className='btn-link nav-toggler d-block d-md-none'
            onClick={() => showMobilemenu()}
          >
            <i className='ti-menu ti-close' />
          </button>
        </div>
        <Collapse className='navbarbg' navbar data-navbarbg='skin1'>
          <Nav className='ml-auto float-right' navbar>
            <NavItem>
              <a
                href='https://www.wrappixel.com/templates/xtreme-react-redux-admin/'
                className='btn btn-danger mr-2'
                style={{ marginTop: '15px' }}
              >
                Upgrade to Pro
              </a>
            </NavItem>
            {/* -------------------------------------------------------------------------------- */}
            {/* Start Profile Dropdown                                                         */}
            {/* -------------------------------------------------------------------------------- */}
            <UncontrolledDropdown nav inNavbar>
              <DropdownToggle nav caret className='pro-pic'>
                <img
                  src={profilephoto}
                  alt='user'
                  className='rounded-circle'
                  width='31'
                />
              </DropdownToggle>
              <DropdownMenu right className='user-dd'>
                <DropdownItem>
                  <i className='ti-user mr-1 ml-1' /> My Account
                </DropdownItem>
                <DropdownItem>
                  <i className='ti-wallet mr-1 ml-1' /> My Balance
                </DropdownItem>
                <DropdownItem>
                  <i className='ti-email mr-1 ml-1' /> Inbox
                </DropdownItem>
                <DropdownItem divider />
                <DropdownItem>
                  <i className='ti-settings mr-1 ml-1' /> Account Settings
                </DropdownItem>
                <DropdownItem divider />
                <DropdownItem href='/pages/login'>
                  <i className='fa fa-power-off mr-1 ml-1' /> Logout
                </DropdownItem>
                <DropdownItem divider />
                <Button color='success' className='btn-rounded ml-3 mb-2 mt-2'>
                  View Profile
                </Button>
              </DropdownMenu>
            </UncontrolledDropdown>
            {/* -------------------------------------------------------------------------------- */}
            {/* End Profile Dropdown                                                           */}
            {/* -------------------------------------------------------------------------------- */}
          </Nav>
        </Collapse>
      </Navbar>
    </header>
  );
};
export default Header;
