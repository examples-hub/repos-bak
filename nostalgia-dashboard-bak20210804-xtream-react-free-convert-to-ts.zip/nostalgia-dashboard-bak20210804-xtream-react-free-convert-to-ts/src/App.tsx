import './index.css';
import '../assets/scss/style.scss';

import * as React from 'react';
import {
  HashRouter,
  Route,
  BrowserRouter as Router,
  Routes,
} from 'react-router-dom';

import indexRoutes from './routes';

export function App() {
  return (
    <Router>
      <Routes>
        {indexRoutes.map((prop, key) => {
          const CompForPath = prop.component;
          return <Route path={prop.path} element={<CompForPath />} key={key} />;
        })}
      </Routes>
    </Router>
  );
}

export default App;
